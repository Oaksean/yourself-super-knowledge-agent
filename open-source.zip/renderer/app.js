'use strict';
/* 随手贴 · 渲染进程 UI（无框架，纯 DOM） */

const $ = (id) => document.getElementById(id);
const S = {
  snapshot: { items: [], categories: [], settings: {}, stats: { total: 0, tracking: 0, updated: 0, tags: [] } },
  view: 'all',
  categoryId: 0,
  tag: '',
  keyword: '',
  selectedId: null,
  tab: 'summary',
  draft: null,
  mode: 'link',
  viewMode: 'list',
  treePending: {},
  mapZoom: 0,
  mapFit: 0.8,
  mapItems: null,
  dupIds: new Set()
};

/* ---------------- 基础工具 ---------------- */
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function fmtTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return String(iso);
  const p = (n) => String(n).padStart(2, '0');
  const now = new Date();
  const sameYear = d.getFullYear() === now.getFullYear();
  return `${sameYear ? '' : d.getFullYear() + '-'}${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}
function typeLabel(t) {
  return { wechat: '公众号', github: 'GitHub', web: '网页', text: '文本', file: '文档' }[t] || '网页';
}
function catName(id) {
  const c = S.snapshot.categories.find((x) => x.id === Number(id));
  return c ? c.name : '未分类';
}
function currentItem() {
  return S.snapshot.items.find((i) => i.id === S.selectedId) || null;
}

let toastTimer = null;
function toast(msg, kind = '', ms = 2600) {
  const wrap = $('toast-wrap');
  const div = document.createElement('div');
  div.className = 'toast ' + kind;
  div.textContent = msg;
  wrap.appendChild(div);
  setTimeout(() => {
    div.style.opacity = '0';
    div.style.transition = 'opacity .2s';
    setTimeout(() => div.remove(), 220);
  }, ms);
}

/* ---------------- 模态框 ---------------- */
function openModal(id) {
  $(id).classList.remove('hidden');
}
function closeModal(id) {
  $(id).classList.add('hidden');
}
function bindCloseButtons() {
  document.querySelectorAll('[data-close]').forEach((btn) => {
    btn.addEventListener('click', () => closeModal(btn.getAttribute('data-close')));
  });
  document.querySelectorAll('.modal-mask').forEach((mask) => {
    mask.addEventListener('mousedown', (e) => {
      if (e.target === mask && mask.id !== 'confirm-modal') mask.classList.add('hidden');
    });
  });
}

function confirmDialog(title, text, { okLabel = '确定', danger = false } = {}) {
  return new Promise((resolve) => {
    $('confirm-title').textContent = title;
    $('confirm-text').textContent = text;
    const ok = $('confirm-ok');
    ok.textContent = okLabel;
    ok.style.background = danger ? '#b42318' : '';
    const cancel = $('confirm-cancel');
    const done = (v) => {
      closeModal('confirm-modal');
      ok.removeEventListener('click', onOk);
      cancel.removeEventListener('click', onCancel);
      resolve(v);
    };
    const onOk = () => done(true);
    const onCancel = () => done(false);
    ok.addEventListener('click', onOk);
    cancel.addEventListener('click', onCancel);
    openModal('confirm-modal');
  });
}

/* ---------------- 数据刷新 ---------------- */
function applySnapshot(snap) {
  if (!snap) return;
  S.snapshot = snap;
  if (S.selectedId && !snap.items.find((i) => i.id === S.selectedId)) {
    S.selectedId = null;
  }
  renderAll();
}

function renderAll() {
  renderSidebar();
  renderList();
  if (S.selectedId) renderDetail();
  renderCatSelects();
  $('count-all').textContent = S.snapshot.items.length;
  $('count-star').textContent = S.snapshot.items.filter((i) => i.starred).length;
  $('count-tracking').textContent = S.snapshot.items.filter((i) => i.enableTrack).length;
  $('count-updated').textContent = S.snapshot.items.filter((i) => i.hasUpdate).length;
}

function renderSidebar() {
  // 快捷过滤
  document.querySelectorAll('#nav-quick .nav-item').forEach((b) => {
    b.classList.toggle('active', S.view === b.dataset.filter);
  });

  // 分类树
  const tree = $('cat-tree');
  tree.innerHTML = '';
  const cats = S.snapshot.categories;
  const counts = {};
  S.snapshot.items.forEach((i) => (counts[i.categoryId] = (counts[i.categoryId] || 0) + 1));

  const rootItems = S.snapshot.items.filter((i) => i.categoryId === 0).length;
  tree.appendChild(catRow({ id: 0, name: '未分类' }, rootItems, false));

  cats.filter((c) => c.parentId === 0).forEach((c) => {
    tree.appendChild(catRow(c, counts[c.id] || 0, false));
    cats.filter((x) => x.parentId === c.id).forEach((ch) => {
      tree.appendChild(catRow(ch, counts[ch.id] || 0, true));
    });
  });

  // 标签云
  const cloud = $('tag-cloud');
  cloud.innerHTML = '';
  const tags = (S.snapshot.stats.tags || []).slice(0, 24);
  if (!tags.length) cloud.innerHTML = '<span class="muted" style="padding:0 4px">暂无标签</span>';
  tags.forEach(({ tag, count }) => {
    const el = document.createElement('button');
    el.className = 'tag-chip' + (S.tag === tag ? ' active' : '');
    el.textContent = `${tag} ${count}`;
    el.addEventListener('click', () => {
      S.tag = S.tag === tag ? '' : tag;
      S.view = 'all';
      S.categoryId = 0;
      renderAll();
    });
    cloud.appendChild(el);
  });
}

function catRow(cat, count, isChild) {
  const row = document.createElement('div');
  row.className = 'cat-row' + (isChild ? ' child' : '') + (S.view === 'category' && S.categoryId === cat.id ? ' active' : '');
  row.innerHTML = `<span class="bar"></span><span class="name">${esc(cat.name)}</span><span class="num">${count}</span>`;
  row.addEventListener('click', () => {
    S.viewMode = 'list';
    S.view = 'category';
    S.categoryId = cat.id;
    S.tag = '';
    renderAll();
  });
  return row;
}

function filteredItems() {
  let items = S.snapshot.items.slice();
  if (S.view === 'star') items = items.filter((i) => i.starred);
  else if (S.view === 'tracking') items = items.filter((i) => i.enableTrack);
  else if (S.view === 'updated') items = items.filter((i) => i.hasUpdate);
  else if (S.view === 'category') items = items.filter((i) => i.categoryId === S.categoryId);
  if (S.tag) items = items.filter((i) => (i.tags || []).includes(S.tag));
  if (S.keyword) {
    const k = S.keyword.toLowerCase();
    items = items.filter((i) =>
      [i.title, i.summary, i.note, (i.tags || []).join(' '), catName(i.categoryId)]
        .join(' ')
        .toLowerCase()
        .includes(k)
    );
  }
  return items;
}

function listHeading() {
  if (S.view === 'star') return '星标知识';
  if (S.view === 'tracking') return '追踪中的知识';
  if (S.view === 'updated') return '有更新的知识';
  if (S.view === 'category') return catName(S.categoryId);
  return '全部知识';
}

/* 同一来源（忽略 utm / 尾斜杠）或同一正文哈希视为重复，用于提示与一键清理 */
function sourceKeyOf(url) {
  if (!url) return '';
  try {
    const u = new URL(String(url).trim());
    u.hash = '';
    ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'from', 'spm'].forEach((k) =>
      u.searchParams.delete(k)
    );
    return (u.hostname.replace(/^www\./i, '').toLowerCase() + u.pathname.replace(/\/+$/, '')).toLowerCase();
  } catch (e) {
    return String(url || '').trim().toLowerCase();
  }
}

function duplicateGroups() {
  const map = new Map();
  (S.snapshot.items || []).forEach((it) => {
    const key = sourceKeyOf(it.sourceUrl) || (it.contentHash ? 'hash:' + it.contentHash : '');
    if (!key) return;
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(it);
  });
  return [...map.values()].filter((g) => g.length > 1);
}

function renderList() {
  const list = $('card-list');
  const items = filteredItems();
  const heading = listHeading() + (S.tag ? ` · #${S.tag}` : '') + (S.keyword ? ` · “${S.keyword}”` : '');
  $('list-title').textContent = heading;
  $('list-count').textContent = `${items.length} 条`;
  document.querySelectorAll('#view-switch button').forEach((b) => {
    b.classList.toggle('active', b.dataset.view === S.viewMode);
  });

  const dups = duplicateGroups();
  S.dupIds = new Set();
  dups.forEach((g) => g.forEach((it) => S.dupIds.add(it.id)));
  const dedupeBtn = $('btn-dedupe');
  if (dedupeBtn) {
    dedupeBtn.classList.toggle('hidden', !dups.length);
    dedupeBtn.textContent = `清理重复（${dups.reduce((n, g) => n + g.length - 1, 0)}）`;
  }

  const empty = $('empty-state');
  const isFiltering = S.keyword || S.tag || S.view !== 'all';
  const treeMode = S.viewMode === 'tree';
  const mapMode = S.viewMode === 'map';
  $('tree-view').classList.toggle('hidden', !treeMode);
  $('map-view').classList.toggle('hidden', !mapMode);

  if (!items.length) {
    list.innerHTML = '';
    list.classList.add('hidden');
    $('tree-view').classList.add('hidden');
    $('map-view').classList.add('hidden');
    empty.classList.remove('hidden');
    empty.querySelector('h3').textContent = isFiltering ? '没有匹配的内容' : '还没有内容';
    empty.querySelector('button').style.display = isFiltering ? 'none' : '';
    return;
  }
  empty.classList.add('hidden');

  if (treeMode || mapMode) {
    list.classList.add('hidden');
    if (treeMode) renderTree();
    else renderMap(items);
    return;
  }

  list.classList.remove('hidden');
  list.innerHTML = '';
  items.forEach((item) => {
    const card = document.createElement('div');
    card.className = 'card' + (S.selectedId === item.id ? ' selected' : '');
    card.dataset.id = item.id;
    const pills = [];
    pills.push(`<span class="pill cat">${esc(catName(item.categoryId))}</span>`);
    (item.tags || []).slice(0, 4).forEach((t) => pills.push(`<span class="pill tag">#${esc(t)}</span>`));
    if (item.enableTrack) pills.push('<span class="pill track">追踪中</span>');
    if (item.hasUpdate) pills.push('<span class="pill update">有更新</span>');
    if ((item.links || []).length) pills.push(`<span class="pill link">链接 ${item.links.length}</span>`);
    if ((S.dupIds || new Set()).has(item.id)) pills.push('<span class="pill dup">疑似重复</span>');
    if (item.starred) pills.push('<span class="pill star">★</span>');

    card.innerHTML = `
      <div class="card-top">
        <span class="type-dot type-${esc(item.sourceType)}"></span>
        <h3>${esc(item.title)}</h3>
        <span class="time">${esc(fmtTime(item.createAt))}</span>
        <button class="card-del" data-del="${item.id}" title="删除这条知识">✕</button>
      </div>
      <p class="summary">${esc(item.summary || '（暂无摘要）')}</p>
      <div class="card-foot">${pills.join('')}</div>
    `;
    card.addEventListener('click', () => openDetail(item.id));
    card.querySelector('.card-del').addEventListener('click', async (e) => {
      e.stopPropagation();
      const ok = await confirmDialog('删除这条知识？', `「${item.title}」的摘要、笔记和版本记录都会被删除，且无法恢复。`, {
        okLabel: '删除',
        danger: true
      });
      if (!ok) return;
      await window.api.deleteItems([item.id]);
      if (S.selectedId === item.id) closeDetail();
      toast('已删除', 'ok', 1500);
    });
    list.appendChild(card);
  });
}

/* ---------------- 思维导图 ---------------- */
function mapGroups(items) {
  const cats = S.snapshot.categories;
  const roots = cats.filter((c) => c.parentId === 0);
  const groups = roots.map((c) => {
    const children = cats.filter((x) => x.parentId === c.id);
    const ids = new Set([c.id].concat(children.map((x) => x.id)));
    return {
      id: c.id,
      name: c.name,
      children: children.map((x) => x.name),
      items: items.filter((i) => ids.has(i.categoryId))
    };
  });
  const unsorted = items.filter((i) => i.categoryId === 0);
  if (unsorted.length) groups.push({ id: 0, name: '未分类', children: [], items: unsorted });
  return groups.filter((g) => g.items.length);
}

function truncateText(s, n) {
  const t = String(s || '');
  return t.length > n ? t.slice(0, n) + '…' : t;
}

function renderMap(items) {
  const box = $('map-view');
  const groups = mapGroups(items);
  if (!groups.length) {
    box.innerHTML = '<div class="muted" style="padding:16px">还没有可生成导图的知识。</div>';
    return;
  }
  const PAD = 24;
  const ROOT_W = 152;
  const ROOT_H = 56;
  const CAT_W = 176;
  const ITEM_W = 292;
  const ITEM_H = 30;
  const ITEM_GAP = 8;
  const CAT_GAP = 24;
  const SHOW_MAX = 8;
  const xRoot = PAD;
  const xCat = PAD + ROOT_W + 62;
  const xItem = xCat + CAT_W + 62;

  const blocks = groups.map((g) => {
    const shown = g.items.slice(0, SHOW_MAX);
    const more = g.items.length - shown.length;
    const rows = shown.length + (more > 0 ? 1 : 0);
    const h = Math.max(ROOT_H, rows * (ITEM_H + ITEM_GAP) - ITEM_GAP);
    return { g, shown, more, h };
  });
  const totalH = blocks.reduce((n, b) => n + b.h, 0) + CAT_GAP * (blocks.length - 1) + PAD * 2;
  const totalW = xItem + ITEM_W + PAD;

  const parts = [];
  const defs = `<defs><linearGradient id="mapLine" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="#4c9a86" stop-opacity="0.55"/><stop offset="1" stop-color="#4c9a86" stop-opacity="0.22"/>
    </linearGradient></defs>`;
  let y = PAD;
  const catNodes = [];
  const itemNodes = [];
  const lines = [];
  const rootCy = totalH / 2;
  blocks.forEach((b) => {
    const cy = y + b.h / 2;
    const catTop = cy - ROOT_H / 2;
    catNodes.push({ x: xCat, y: catTop, b, cy });
    catNodes[catNodes.length - 1].lines = [];
    let iy = cy - (b.shown.length * (ITEM_H + ITEM_GAP) - ITEM_GAP) / 2 + (b.more > 0 ? ITEM_H / 2 : 0);
    b.shown.forEach((it) => {
      itemNodes.push({ x: xItem, y: iy, item: it, block: b });
      iy += ITEM_H + ITEM_GAP;
    });
    if (b.more > 0) itemNodes.push({ x: xItem, y: iy, more: b.more, block: b });
    y += b.h + CAT_GAP;
  });

  const catByBlock = new Map();
  catNodes.forEach((c) => catByBlock.set(c.b, c));
  catNodes.forEach((c) => {
    lines.push(
      `<path class="map-link root" d="M ${xRoot + ROOT_W} ${rootCy} C ${xRoot + ROOT_W + 30} ${rootCy}, ${c.x - 30} ${c.cy}, ${c.x} ${c.cy}" />`
    );
  });
  itemNodes.forEach((n) => {
    const cy = n.y + ITEM_H / 2;
    const target = catByBlock.get(n.block);
    if (!target) return;
    lines.push(
      `<path class="map-link" d="M ${target.x + CAT_W} ${target.cy} C ${target.x + CAT_W + 30} ${target.cy}, ${n.x - 30} ${cy}, ${n.x} ${cy}" />`
    );
  });

  const rootLabel = truncateText(`随手贴 · ${items.length} 条`, 12);
  const rootSub = `${groups.length} 个分类`;
  // 默认「适应宽度」：内容比可视区宽时整体缩放，避免右边被裁掉、看不出全貌
  const viewW = Math.max(520, (box.clientWidth || 900) - 44);
  const fit = Math.min(1, viewW / totalW);
  S.mapFit = fit;
  S.mapItems = items;
  const scale = S.mapZoom > 0 ? S.mapZoom : fit;

  parts.push(defs);
  parts.push(
    `<g class="map-node root" data-root="1">
      <rect x="${xRoot}" y="${rootCy - ROOT_H / 2}" width="${ROOT_W}" height="${ROOT_H}" rx="12"/>
      <text class="t" x="${xRoot + 14}" y="${rootCy + 1}">${esc(rootLabel)}</text>
      <text class="s" x="${xRoot + 14}" y="${rootCy + 18}">${esc(rootSub)}</text>
    </g>`
  );
  catNodes.forEach((c) => {
    const g = c.b.g;
    parts.push(
      `<g class="map-node cat" data-cat="${g.id}">
        <rect x="${c.x}" y="${c.y}" width="${CAT_W}" height="${ROOT_H}" rx="10"/>
        <text class="t" x="${c.x + 14}" y="${c.y + 26}">${esc(truncateText(g.name, 10))}</text>
        <text class="s" x="${c.x + 14}" y="${c.y + 43}">${g.items.length} 条${g.children.length ? ' · ' + g.children.length + ' 子类' : ''}</text>
      </g>`
    );
  });
  itemNodes.forEach((n) => {
    if (n.more) {
      parts.push(
        `<g class="map-node more">
          <rect x="${n.x}" y="${n.y}" width="${ITEM_W}" height="${ITEM_H}" rx="8"/>
          <text class="t" x="${n.x + 12}" y="${n.y + 19}">还有 ${n.more} 条，点「查看列表」展开</text>
        </g>`
      );
      return;
    }
    const it = n.item;
    const title = truncateText(it.title, 22);
    parts.push(
      `<g class="map-node item" data-item="${it.id}" data-cat="${it.categoryId}">
        <rect x="${n.x}" y="${n.y}" width="${ITEM_W}" height="${ITEM_H}" rx="8"/>
        <circle cx="${n.x + 13}" cy="${n.y + ITEM_H / 2}" r="3" class="dot kind-${esc(it.sourceType)}"/>
        <text class="t" x="${n.x + 24}" y="${n.y + 19}">${esc(title)}</text>
      </g>`
    );
  });

  box.innerHTML = `
    <div class="map-bar">
      <span class="muted">共 ${groups.length} 个分类 · ${items.length} 条知识 · 点节点查看，点分类回到列表</span>
      <span class="spacer"></span>
      <button class="ghost small" data-zoom="out">－</button>
      <span class="muted" data-zoom-label>${Math.round(scale * 100)}%</span>
      <button class="ghost small" data-zoom="in">＋</button>
      <button class="ghost small" data-zoom="fit">适应宽度</button>
    </div>
    <div class="map-scroll">
      <div class="map-stage" style="width:${Math.round(totalW * scale)}px;height:${Math.round(totalH * scale)}px">
        <svg class="map-svg" width="${totalW}" height="${totalH}" viewBox="0 0 ${totalW} ${totalH}"
             style="transform:scale(${scale});transform-origin:0 0">
          ${lines.join('')}
          ${parts.join('')}
        </svg>
      </div>
    </div>`;

  box.querySelectorAll('[data-zoom]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const act = btn.dataset.zoom;
      const cur = S.mapZoom > 0 ? S.mapZoom : fit;
      if (act === 'fit') S.mapZoom = 0;
      else if (act === 'in') S.mapZoom = Math.min(2, cur * 1.2);
      else S.mapZoom = Math.max(0.3, cur / 1.2);
      const scroll = box.querySelector('.map-scroll');
      const top = scroll ? scroll.scrollTop : 0;
      renderMap(S.mapItems || items);
      const next = $('map-view').querySelector('.map-scroll');
      if (next) next.scrollTop = top;
    });
  });

  box.querySelectorAll('.map-node.item').forEach((node) => {
    node.addEventListener('click', () => openDetail(Number(node.dataset.item)));
  });
  box.querySelectorAll('.map-node.cat').forEach((node) => {
    node.addEventListener('click', () => {
      S.view = 'cat';
      S.catId = Number(node.dataset.cat);
      S.viewMode = 'list';
      renderAll();
    });
  });
}

/* ---------------- 知识树 ---------------- */
function treeGroups() {
  const cats = S.snapshot.categories;
  const items = S.snapshot.items;
  const roots = cats.filter((c) => c.parentId === 0);
  const groups = roots.map((c) => {
    const children = cats.filter((x) => x.parentId === c.id);
    const ids = new Set([c.id].concat(children.map((x) => x.id)));
    return {
      id: c.id,
      name: c.name,
      children: children.map((x) => x.name),
      items: items.filter((i) => ids.has(i.categoryId))
    };
  });
  const unsorted = items.filter((i) => i.categoryId === 0);
  if (unsorted.length) groups.push({ id: 0, name: '未分类', children: [], items: unsorted });
  return groups.filter((g) => g.items.length);
}

function treeCardMarkup(g, sum) {
  const pending = !sum || Number(sum.count) !== g.items.length;
  const summaryText = sum && sum.summary ? esc(sum.summary) : '正在整理这一分类的脉络…';
  const points = sum && (sum.keyPoints || []).length
    ? `<ul class="tree-points">${sum.keyPoints.slice(0, 4).map((p) => `<li>${esc(p)}</li>`).join('')}</ul>`
    : '';
  const tags = sum && (sum.tags || []).length
    ? `<div class="link-chips">${sum.tags.slice(0, 8).map((t) => `<span class="tag-chip">#${esc(t)}</span>`).join('')}</div>`
    : '';
  const show = g.items.slice(0, 8);
  const list = show
    .map(
      (it) =>
        `<li data-item="${it.id}"><span class="t">${esc(it.title)}</span><span class="d">${esc(fmtTime(it.createAt))}</span></li>`
    )
    .join('');
  return `<section class="tree-card" data-cat="${g.id}">
    <div class="tree-head">
      <div>
        <h3>${esc(g.name)}<span class="num">${g.items.length} 条</span></h3>
        ${g.children.length ? `<p class="tree-sub">子分类：${esc(g.children.join('、'))}</p>` : ''}
      </div>
      <div class="tree-actions">
        <button class="ghost small" data-act="regen">重新总结</button>
        <button class="ghost small" data-act="open">查看列表</button>
      </div>
    </div>
    <div class="tree-summary${pending ? ' pending' : ''}" data-summary="${g.id}">${summaryText}</div>
    ${points}${tags}
    <ul class="tree-items">${list}</ul>
    ${g.items.length > show.length ? `<div class="tree-more">还有 ${g.items.length - show.length} 条，点「查看列表」展开</div>` : ''}
  </section>`;
}

function renderTree() {
  const box = $('tree-view');
  const groups = treeGroups();
  if (!groups.length) {
    box.innerHTML = '<div class="muted">还没有可归类的知识，先新增几条再来看知识树。</div>';
    return;
  }
  const sums = S.snapshot.categorySummaries || {};
  box.innerHTML = `<div class="tree-grid">${groups.map((g) => treeCardMarkup(g, sums[String(g.id)])).join('')}</div>`;

  box.querySelectorAll('.tree-card').forEach((card) => {
    const id = Number(card.dataset.cat);
    card.querySelectorAll('li[data-item]').forEach((li) => {
      li.addEventListener('click', () => openDetail(Number(li.dataset.item)));
    });
    card.querySelector('[data-act="open"]').addEventListener('click', () => {
      S.viewMode = 'list';
      S.view = 'category';
      S.categoryId = id;
      renderAll();
    });
    card.querySelector('[data-act="regen"]').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      btn.textContent = '整理中…';
      const r = await window.api.treeSummary({ categoryId: id, force: true });
      btn.disabled = false;
      btn.textContent = '重新总结';
      if (!r.ok) return toast(r.error, 'err');
      S.snapshot.categorySummaries = S.snapshot.categorySummaries || {};
      S.snapshot.categorySummaries[String(id)] = r.data;
      if (S.viewMode === 'tree') renderTree();
    });
  });

  ensureTreeSummaries(groups);
}

function ensureTreeSummaries(groups) {
  const sums = S.snapshot.categorySummaries || {};
  groups.forEach((g) => {
    const cached = sums[String(g.id)];
    const valid = cached && Number(cached.count) === g.items.length && cached.summary;
    if (valid) return;
    if (S.treePending[g.id]) return;
    S.treePending[g.id] = true;
    window.api.treeSummary({ categoryId: g.id }).then((r) => {
      S.treePending[g.id] = false;
      if (!r.ok) return;
      S.snapshot.categorySummaries = S.snapshot.categorySummaries || {};
      S.snapshot.categorySummaries[String(g.id)] = r.data;
      if (S.viewMode === 'tree') renderTree();
    });
  });
}

/* ---------------- 详情 ---------------- */
function openDetail(id) {
  S.selectedId = id;
  S.tab = 'summary';
  document.getElementById('app').classList.add('detail-open');
  $('detail').classList.remove('hidden');
  renderDetail();
  renderList();
}

function closeDetail() {
  S.selectedId = null;
  $('detail').classList.add('hidden');
  document.getElementById('app').classList.remove('detail-open');
  renderList();
}

function renderDetail() {
  const item = currentItem();
  if (!item) return closeDetail();

  document.querySelectorAll('#detail-tabs button').forEach((b) => {
    b.classList.toggle('active', b.dataset.tab === S.tab);
  });
  $('note-dot').classList.toggle('show', !!(item.note && item.note.trim()));
  $('ver-dot').classList.toggle('show', (item.versions || []).length > 0 || item.hasUpdate);

  const body = $('detail-body');
  if (S.tab === 'summary') {
    const cats = S.snapshot.categories;
    const catOpts = [`<option value="0"${item.categoryId === 0 ? ' selected' : ''}>未分类</option>`]
      .concat(
        cats.map(
          (c) =>
            `<option value="${c.id}"${item.categoryId === c.id ? ' selected' : ''}>${esc((c.parentId ? '　' : '') + c.name)}</option>`
        )
      )
      .join('');

    body.innerHTML = `
      <h2 class="detail-title">${esc(item.title)}</h2>
      <div class="detail-meta">
        <span class="pill">${typeLabel(item.sourceType)}</span>
        <span class="pill">${esc(fmtTime(item.createAt))}</span>
        ${item.sourceUrl ? `<button class="link-btn" id="btn-open-src">↗ ${esc(item.sourceType === 'file' ? '打开本地文件' : shortUrl(item.sourceUrl))}</button>` : ''}
        ${item.hasUpdate ? '<span class="pill update">来源已更新</span>' : ''}
      </div>
      <div class="block-title">分类</div>
      <select class="select" id="detail-cat">${catOpts}</select>
      <div class="block-title">AI 摘要</div>
      <div class="summary-text">${esc(item.summary || '（无摘要）')}</div>
      <div class="block-title">核心要点</div>
      ${
        (item.keyPoints || []).length
          ? `<ul class="points">${item.keyPoints.map((p) => `<li>${esc(p)}</li>`).join('')}</ul>`
          : '<div class="muted">（无）</div>'
      }
      <div class="block-title between"><span>相关链接${(item.links || []).length ? `（${item.links.length}）` : ''}</span>${
        item.sourceUrl && item.sourceType !== 'file'
          ? '<span class="between-actions"><button class="mini" id="btn-reextract" title="重新抓取正文、重算摘要、重抽外链">重新抓取</button><button class="mini" id="btn-relink">只补外链</button></span>'
          : ''
      }</div>
      <div id="detail-links">${
        (item.links || []).length
          ? `<div class="link-chips">${linkChipsMarkup(item.links)}</div>`
          : `<div class="muted">${item.sourceType === 'file' ? '导入时没有选择抓取链接，可重新导入勾选。' : item.sourceUrl ? '正文里没有可提取的外链，可点“重新抓取”再试一次。' : '该条目是手动录入的文本，没有外链。'}</div>`
      }</div>
      <div class="block-title">标签</div>
      <div class="tag-edit" id="tag-edit">
        ${(item.tags || [])
          .map((t) => `<button class="tag-chip" data-tag="${esc(t)}">${esc(t)} ✕</button>`)
          .join('')}
        <input id="tag-input" placeholder="+ 标签" />
      </div>
      <div class="block-title">来源信息</div>
      <div class="muted" style="line-height:1.8">
        原文长度：${item.charCount || 0} 字<br/>
        最后检查：${esc(fmtTime(item.lastCheckAt) || '未检查')}<br/>
        ${item.sourceType === 'file' ? '源文件' : '原文地址'}：${esc(item.sourceUrl || '（无，手动录入）')}
      </div>
    `;

    if ($('btn-open-src')) {
      $('btn-open-src').addEventListener('click', async () => {
        if (item.sourceType === 'file') {
          const r = await window.api.openFile(item.sourceUrl);
          if (!r.ok) toast(r.error || '打不开文件', 'err');
        } else {
          window.api.openExternal(item.sourceUrl);
        }
      });
    }
    bindLinkChips('detail-links');
    if ($('btn-reextract')) {
      $('btn-reextract').addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        btn.disabled = true;
        btn.textContent = '抓取中…';
        const r = await window.api.reextract(item.id);
        btn.disabled = false;
        btn.textContent = '重新抓取';
        if (!r.ok) return toast(r.error, 'err');
        toast(r.changed ? '已重新抓取：正文有变化，旧摘要已存入版本记录' : '已重新抓取：正文未变化，摘要已按最新规则重算', 'ok', 2600);
      });
    }
    if ($('btn-relink')) {
      $('btn-relink').addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        btn.disabled = true;
        btn.textContent = '提取中…';
        const r = await window.api.refreshLinks(item.id);
        if (r.ok) toast(`提取到 ${(r.links || []).length} 条外链`, 'ok', 1800);
        else toast(r.error, 'err');
      });
    }
    $('detail-cat').addEventListener('change', async (e) => {
      const r = await window.api.updateItem(item.id, { categoryId: Number(e.target.value) });
      if (r.ok) toast('分类已更新', 'ok', 1500);
      else toast(r.error, 'err');
    });
    document.querySelectorAll('#tag-edit .tag-chip').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const tag = btn.dataset.tag;
        const tags = (item.tags || []).filter((t) => t !== tag);
        const r = await window.api.updateItem(item.id, { tags });
        if (!r.ok) toast(r.error, 'err');
      });
    });
    $('tag-input').addEventListener('keydown', async (e) => {
      if (e.key !== 'Enter') return;
      const v = e.target.value.trim();
      if (!v) return;
      const tags = Array.from(new Set([...(item.tags || []), v]));
      const r = await window.api.updateItem(item.id, { tags });
      e.target.value = '';
      if (!r.ok) toast(r.error, 'err');
    });
  } else if (S.tab === 'note') {
    body.innerHTML = `
      <div class="block-title" style="margin-top:0">我的笔记（自动保存）</div>
      <textarea class="note-area" id="note-area" placeholder="写下你的思考、批注、待办…">${esc(item.note || '')}</textarea>
      <p class="hint">摘要是对原文的提炼，笔记是你自己的内容，两者独立保存。</p>
    `;
    const area = $('note-area');
    let timer = null;
    area.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        const r = await window.api.updateItem(item.id, { note: area.value });
        if (r.ok) toast('笔记已保存', 'ok', 1200);
      }, 700);
    });
    area.focus();
    area.setSelectionRange(area.value.length, area.value.length);
  } else {
    const versions = item.versions || [];
    body.innerHTML = `
      ${
        item.hasUpdate
          ? `<div class="pill update" style="display:inline-block;margin-bottom:10px">检测到来源更新，摘要已替换为新版本</div>`
          : ''
      }
      <div class="block-title" style="margin-top:0">当前版本</div>
      <div class="version-item">
        <div class="when">${esc(fmtTime(item.updatedAt))}</div>
        <div class="what">${esc(item.summary || '（无摘要）')}</div>
      </div>
      <div class="block-title">历史版本（${versions.length}）</div>
      ${
        versions.length
          ? versions
              .map(
                (v) => `<div class="version-item">
                  <div class="when">${esc(fmtTime(v.createAt))}${v.title ? ' · ' + esc(v.title) : ''}</div>
                  <div class="what">${esc(v.summary || '（无摘要）')}</div>
                </div>`
              )
              .join('')
          : '<div class="muted">还没有历史版本。开启追踪后，来源更新时会自动留档。</div>'
      }
      <div class="row">
        <button class="ghost" id="btn-mark-read">标记为已读</button>
        <button class="ghost" id="btn-recheck-detail">立即检查来源</button>
      </div>
    `;
    $('btn-mark-read').addEventListener('click', async () => {
      await window.api.updateItem(item.id, { hasUpdate: false });
      toast('已标记为已读', 'ok', 1500);
    });
    $('btn-recheck-detail').addEventListener('click', () => recheck(item));
  }

  renderDetailFoot(item);
}

function shortUrl(u) {
  try {
    const x = new URL(u);
    const p = x.pathname.length > 34 ? x.pathname.slice(0, 34) + '…' : x.pathname;
    return x.hostname + p;
  } catch (e) {
    return u.slice(0, 48);
  }
}

function linkChipsMarkup(links) {
  return (links || [])
    .map((l) => {
      const site = l.site || '链接';
      return `<button class="link-chip kind-${esc(l.kind || 'other')}" data-url="${esc(l.url)}" title="${esc(
        l.url
      )}"><b>${esc(site)}</b><span class="lbl">${esc(l.label || l.url)}</span></button>`;
    })
    .join('');
}

function bindLinkChips(containerId) {
  const box = $(containerId);
  if (!box) return;
  box.querySelectorAll('.link-chip[data-url]').forEach((btn) => {
    btn.addEventListener('click', () => window.api.openExternal(btn.dataset.url));
  });
}

function renderDetailFoot(item) {
  const foot = $('detail-foot');
  foot.innerHTML = `
    <label class="track-toggle">
      <span class="switch ${item.enableTrack ? 'on' : ''}" id="sw-track"></span>
      追踪更新
    </label>
    <select class="select small" id="foot-track-hours">
      ${[
        [6, '6小时'],
        [12, '12小时'],
        [24, '每天'],
        [72, '3天'],
        [168, '7天']
      ]
        .map(([v, l]) => `<option value="${v}"${item.trackIntervalHours === v ? ' selected' : ''}>${l}</option>`)
        .join('')}
    </select>
    <span class="spacer"></span>
    <button class="ghost" id="foot-star">${item.starred ? '★ 已星标' : '☆ 星标'}</button>
    <button class="ghost" id="foot-export">导出 md</button>
    <button class="ghost" id="foot-recheck">检查更新</button>
    <button class="danger" id="foot-delete">删除</button>
  `;

  $('sw-track').addEventListener('click', async () => {
    const next = !item.enableTrack;
    if (next && !item.sourceUrl) {
      toast('该条目没有来源链接，无法追踪', 'err');
      return;
    }
    const r = await window.api.updateItem(item.id, { enableTrack: next });
    toast(next ? '已开启追踪' : '已关闭追踪', 'ok', 1500);
    if (!r.ok) toast(r.error, 'err');
    renderDetail();
  });
  $('foot-track-hours').addEventListener('change', async (e) => {
    await window.api.updateItem(item.id, { trackIntervalHours: Number(e.target.value), enableTrack: true });
    toast('追踪周期已更新', 'ok', 1500);
    renderDetail();
  });
  $('foot-star').addEventListener('click', async () => {
    await window.api.updateItem(item.id, { starred: !item.starred });
  });
  $('foot-export').addEventListener('click', async () => {
    const r = await window.api.exportMarkdown({ ids: [item.id] });
    if (r.ok && !r.canceled) toast('已导出：' + r.path, 'ok');
    else if (r.ok === false) toast(r.error, 'err');
  });
  $('foot-recheck').addEventListener('click', () => recheck(item));
  $('foot-delete').addEventListener('click', async () => {
    const ok = await confirmDialog('删除这条知识？', `「${item.title}」的摘要、笔记和版本记录都会被删除，且无法恢复。`, {
      okLabel: '删除',
      danger: true
    });
    if (!ok) return;
    await window.api.deleteItems([item.id]);
    closeDetail();
    toast('已删除', 'ok', 1500);
  });
}

async function recheck(item) {
  if (!item.sourceUrl) return toast('该条目没有来源链接', 'err');
  toast('正在检查来源…', '', 2000);
  const r = await window.api.recheckItem(item.id, true);
  if (!r.ok) return toast(r.error, 'err');
  toast(r.changed ? '来源有变化，已生成新版本摘要' : '来源没有变化', 'ok', 2600);
}

/* ---------------- 分类 ---------------- */
function renderCatSelects() {
  const cats = S.snapshot.categories;
  const catSelect = $('cat-parent');
  if (catSelect) {
    catSelect.innerHTML =
      '<option value="0">一级分类</option>' +
      cats.filter((c) => c.parentId === 0).map((c) => `<option value="${c.id}">${esc(c.name)} 下</option>`).join('');
  }
  const draftCat = $('draft-category');
  if (draftCat && S.draft) {
    const suggested = (S.draft.category || '').trim();
    const has = cats.some((c) => c.name === suggested);
    draftCat.innerHTML =
      `<option value="0"${S.draft.categoryId === 0 && !suggested ? ' selected' : ''}>未分类</option>` +
      cats.map((c) => `<option value="${c.id}"${S.draft.categoryId === c.id ? ' selected' : ''}>${esc(c.name)}</option>`).join('') +
      (!has && suggested
        ? `<option value="new:${esc(suggested)}" selected>＋ 新建分类「${esc(suggested)}」</option>`
        : '');
  }
}

/* ---------------- 新增知识 ---------------- */
function openAddModal(prefillUrl) {
  S.draft = null;
  S.filePath = null;
  $('draft-area').classList.add('hidden');
  $('draft-fetch-wrap').classList.add('hidden');
  $('file-meta').classList.add('hidden');
  $('file-meta').innerHTML = '';
  $('file-status').className = 'status';
  $('file-status').textContent = '支持 .docx / .xlsx（.doc / .xls 请先另存为新格式）';
  $('btn-save-draft').disabled = true;
  $('capture-status').textContent = '';
  $('capture-status').className = 'status';
  $('input-url').value = prefillUrl || '';
  $('input-text').value = '';
  $('draft-meta').textContent = '';
  setAddMode('link');
  openModal('add-modal');
  setTimeout(() => {
    (S.mode === 'link' ? $('input-url') : $('input-text')).focus();
  }, 60);
}

function setAddMode(mode) {
  S.mode = mode;
  document.querySelectorAll('#add-mode button').forEach((b) => b.classList.toggle('active', b.dataset.mode === mode));
  $('pane-link').classList.toggle('hidden', mode !== 'link');
  $('pane-text').classList.toggle('hidden', mode !== 'text');
  $('pane-file').classList.toggle('hidden', mode !== 'file');
  $('btn-capture').textContent = mode === 'file' ? '重新解析文件' : '抓取并提炼';
  $('draft-fetch-wrap').classList.toggle('hidden', !(mode === 'file' && S.draft && S.draft.sourceType === 'file'));
}

async function parseFile(filePath) {
  const status = $('capture-status');
  status.className = 'status';
  status.textContent = '正在解析文档并提炼…';
  $('btn-capture').disabled = true;
  try {
    const r = await window.api.analyzeFile(filePath);
    if (!r.ok) {
      status.className = 'status err';
      status.textContent = '解析失败：' + r.error;
      toast('解析失败：' + r.error, 'err', 4200);
      return;
    }
    S.filePath = filePath;
    S.draft = r.draft;
    fillDraft(r.draft);
    $('file-meta').classList.remove('hidden');
    $('file-meta').innerHTML =
      `<b>${esc(r.draft.fileName)}</b> · ${esc(r.draft.docDetail || '')} · 识别到 ${esc(String((r.draft.docLinks || []).length))} 个链接` +
      (r.draft.warning ? `<span class="muted">（${esc(r.draft.warning)}）</span>` : '');
    $('draft-fetch-wrap').classList.remove('hidden');
    $('btn-save-draft').disabled = false;
    $('draft-area').classList.remove('hidden');
    status.className = 'status ok';
    status.textContent =
      `解析完成 · ${r.draft.charCount} 字 · ${r.draft.summarySource === 'llm' ? '大模型解析' : '本地解析'}`;
  } finally {
    $('btn-capture').disabled = false;
  }
}

async function pickFileAndParse() {
  const r = await window.api.pickFile();
  if (!r.ok) {
    if (r.canceled) return;
    return toast('选择文件失败：' + r.error, 'err');
  }
  $('file-status').className = 'status';
  $('file-status').textContent = r.name;
  await parseFile(r.path);
}

async function doCapture() {
  if (S.mode === 'file') {
    if (!S.filePath) return toast('请先选择要导入的 Word / Excel 文件', 'err');
    return parseFile(S.filePath);
  }
  const url = $('input-url').value.trim();
  const text = $('input-text').value.trim();
  const payload = S.mode === 'link' ? { url } : { rawText: text };
  if (S.mode === 'link' && !url) return toast('请先粘贴链接', 'err');
  if (S.mode === 'text' && !text) return toast('请先粘贴文字', 'err');

  const status = $('capture-status');
  status.className = 'status';
  status.textContent = '正在抓取并提炼，请稍候…';
  $('btn-capture').disabled = true;

  try {
    const r = await window.api.previewCapture(payload);
    if (!r.ok) {
      status.className = 'status err';
      status.textContent = '失败：' + r.error;
      toast('抓取失败：' + r.error, 'err', 4200);
      return;
    }
    S.draft = r.draft;
    fillDraft(r.draft);
    status.className = 'status ok';
    status.textContent =
      `完成 · ${r.draft.charCount} 字 · ${r.draft.summarySource === 'llm' ? '大模型摘要' : '本地摘要'}` +
      (r.draft.warning ? '（' + r.draft.warning + '）' : '');
    $('btn-save-draft').disabled = false;
    $('draft-area').classList.remove('hidden');
  } finally {
    $('btn-capture').disabled = false;
  }
}

function fillDraft(d) {
  $('draft-title').value = d.title || '';
  $('draft-summary').value = d.summary || '';
  $('draft-points').value = (d.keyPoints || []).join('\n');
  $('draft-tags').value = (d.tags || []).join('，');
  const isFile = d.sourceType === 'file';
  $('draft-track').checked = !!d.sourceUrl && !isFile;
  $('draft-fetch-wrap').classList.toggle('hidden', !isFile);
  if (isFile) $('draft-track').checked = false;
  const links = d.links || [];
  const wrap = $('draft-links-wrap');
  $('draft-links').innerHTML = links.length ? links.map((l) => `<button class="link-chip kind-${esc(l.kind || 'other')}" data-url="${esc(l.url)}" title="${esc(l.url)}"><b>${esc(l.site || '链接')}</b><span class="lbl">${esc(l.label || l.url)}</span></button>`).join('') : '';
  wrap.classList.toggle('hidden', !links.length);
  bindLinkChips('draft-links');
  renderCatSelects();
  $('draft-meta').textContent = isFile
    ? `来源：文档 · ${d.fileName || shortUrl(d.filePath || '')}`
    : `来源：${typeLabel(d.sourceType)}${d.sourceUrl ? ' · ' + shortUrl(d.sourceUrl) : ''}`;
}

async function saveDraft() {
  if (!S.draft) return;
  const catVal = $('draft-category').value;
  let categoryId = Number(catVal) || 0;
  if (String(catVal).startsWith('new:')) {
    const name = String(catVal).slice(4);
    const r = await window.api.addCategory({ name, parentId: 0 });
    if (r.ok) categoryId = r.category.id;
    else return toast('创建分类失败：' + r.error, 'err');
  }
  const payload = {
    title: $('draft-title').value.trim(),
    sourceUrl: S.draft.sourceUrl,
    sourceType: S.draft.sourceType,
    summary: $('draft-summary').value.trim(),
    keyPoints: $('draft-points')
      .value.split('\n')
      .map((s) => s.trim())
      .filter(Boolean),
    tags: $('draft-tags')
      .value.split(/[，,、]/)
      .map((s) => s.trim())
      .filter(Boolean),
    categoryId,
    contentHash: S.draft.contentHash,
    coverUrl: S.draft.coverUrl,
    charCount: S.draft.charCount,
    links: S.draft.links || [],
    enableTrack: $('draft-track').checked,
    trackIntervalHours: Number($('draft-track-hours').value) || 24
  };
  if (!payload.title) return toast('标题不能为空', 'err');

  // 文档导入：文件条目 + 可选把文中链接各存一条知识
  if (S.draft.sourceType === 'file' && S.mode === 'file') {
    const fetchLinks = $('draft-fetch-links').checked;
    $('btn-save-draft').disabled = true;
    try {
      const r = await window.api.importFile({ draft: { ...payload, sourceType: 'file' }, fetchLinks });
      if (!r.ok) return toast('导入失败：' + r.error, 'err', 4200);
      closeModal('add-modal');
      S.draft = null;
      S.filePath = null;
      const linked = (r.added || []).length;
      const failed = (r.failed || []).length;
      toast(
        `已入库 1 条文档知识${linked ? `，并抓取 ${linked} 条链接知识` : ''}${failed ? `（${failed} 条链接抓取失败）` : ''}`,
        'ok',
        3600
      );
      if (r.item) openDetail(r.item.id);
    } finally {
      $('btn-save-draft').disabled = false;
    }
    return;
  }

  // 防重复：同一来源（忽略 utm / 尾斜杠）、同一正文哈希，或标题高度接近时先提示
  const dup = await window.api.findDuplicate({
    sourceUrl: payload.sourceUrl,
    contentHash: payload.contentHash,
    title: payload.title
  });
  if (dup.ok && dup.matches.length) {
    const first = dup.matches[0];
    const sameSource = first.reason === 'same-source' || first.reason === 'same-content';
    if (!sameSource) {
      const stillAdd = await confirmDialog(
        '可能有同主题的重复知识',
        `知识库里已有标题很接近的「${first.title}」（创建于 ${fmtTime(first.createAt)}）。确定要再新增一条吗？`,
        { okLabel: '仍然新增', danger: true }
      );
      if (!stillAdd) return;
    } else {
      const update = await confirmDialog(
        '这条知识已经收录过',
        `知识库里已有「${first.title}」（创建于 ${fmtTime(first.createAt)}）。是否用本次抓取结果更新那一条，而不是再新增一条重复知识？`,
        { okLabel: '更新已有' }
      );
      if (update) {
        const r2 = await window.api.updateItem(first.id, {
          summary: payload.summary,
          keyPoints: payload.keyPoints,
          tags: payload.tags && payload.tags.length ? payload.tags : undefined,
          categoryId: payload.categoryId,
          contentHash: payload.contentHash,
          coverUrl: payload.coverUrl,
          charCount: payload.charCount,
          links: payload.links
        });
        if (!r2.ok) return toast('更新失败：' + r2.error, 'err');
        closeModal('add-modal');
        S.draft = null;
        toast('已更新已有知识，未产生重复条目', 'ok');
        openDetail(first.id);
        return;
      }
      const stillAdd = await confirmDialog('仍然新增一条重复知识？', '确定要保留两条相同来源的内容吗？列表里会标注「疑似重复」。', {
        okLabel: '仍然新增',
        danger: true
      });
      if (!stillAdd) return;
    }
  }

  const r = await window.api.saveCapture(payload);
  if (!r.ok) return toast('保存失败：' + r.error, 'err');
  closeModal('add-modal');
  S.draft = null;
  toast('已保存到知识库', 'ok');
  if (r.item) openDetail(r.item.id);
}

/* ---------------- 设置 ---------------- */
function fillSettings(s) {
  $('set-llm-enabled').checked = !!s.llm.enabled;
  $('set-llm-url').value = s.llm.baseUrl || '';
  $('set-llm-key').value = s.llm.apiKey || '';
  $('set-llm-model').value = s.llm.model || '';
  $('set-gh-token').value = s.githubToken || '';
  $('set-track-interval').value = String(s.trackIntervalMinutes || 60);
  $('set-clipboard').checked = !!s.clipboardWatch;
}

async function saveSettings() {
  const patch = {
    llm: {
      enabled: $('set-llm-enabled').checked,
      baseUrl: $('set-llm-url').value.trim(),
      apiKey: $('set-llm-key').value.trim(),
      model: $('set-llm-model').value.trim()
    },
    githubToken: $('set-gh-token').value.trim(),
    trackIntervalMinutes: Number($('set-track-interval').value) || 60,
    clipboardWatch: $('set-clipboard').checked
  };
  const r = await window.api.saveSettings(patch);
  if (!r.ok) return toast('保存失败：' + r.error, 'err');
  $('save-status').textContent = '已保存';
  toast('设置已保存', 'ok', 1800);
  setTimeout(() => ($('save-status').textContent = ''), 2000);
}

/* ---------------- 事件绑定 ---------------- */
function bindEvents() {
  $('btn-add').addEventListener('click', () => openAddModal());
  $('empty-add').addEventListener('click', () => openAddModal());
  $('btn-detail-close').addEventListener('click', closeDetail);
  $('btn-settings').addEventListener('click', () => {
    fillSettings(S.snapshot.settings);
    $('data-file-path').textContent = '数据文件：' + (S.snapshot.dataFile || '（未知）');
    openModal('settings-modal');
  });

  // 搜索
  const search = $('search');
  search.addEventListener('input', () => {
    S.keyword = search.value.trim();
    $('search-clear').classList.toggle('hidden', !S.keyword);
    renderList();
  });
  $('search-clear').addEventListener('click', () => {
    search.value = '';
    S.keyword = '';
    $('search-clear').classList.add('hidden');
    renderList();
  });

  // 视图切换：列表 / 知识树 / 思维导图
  document.querySelectorAll('#view-switch button').forEach((b) => {
    b.addEventListener('click', () => {
      S.viewMode = b.dataset.view;
      renderAll();
    });
  });

  // 一键清理重复：同来源只保留最新一条
  $('btn-dedupe').addEventListener('click', async () => {
    const groups = duplicateGroups();
    if (!groups.length) return toast('没有发现重复知识', 'ok', 1500);
    const total = groups.reduce((n, g) => n + g.length - 1, 0);
    const ok = await confirmDialog(
      `清理 ${total} 条重复知识？`,
      `发现 ${groups.length} 组来源相同的知识，每组只保留最新的一条，其余连同笔记一起删除。`,
      { okLabel: '清理', danger: true }
    );
    if (!ok) return;
    const ids = [];
    groups.forEach((g) => {
      const sorted = g.slice().sort((a, b) => String(b.createAt).localeCompare(String(a.createAt)));
      sorted.slice(1).forEach((it) => ids.push(it.id));
    });
    const r = await window.api.deleteItems(ids);
    if (!r.ok) return toast(r.error, 'err');
    toast(`已清理 ${ids.length} 条重复知识`, 'ok');
  });

  // 快捷过滤
  document.querySelectorAll('#nav-quick .nav-item').forEach((b) => {
    b.addEventListener('click', () => {
      S.viewMode = 'list';
      S.view = b.dataset.filter;
      S.categoryId = 0;
      S.tag = '';
      renderAll();
    });
  });

  // 新增
  document.querySelectorAll('#add-mode button').forEach((b) => {
    b.addEventListener('click', () => setAddMode(b.dataset.mode));
  });
  $('btn-capture').addEventListener('click', doCapture);
  $('btn-save-draft').addEventListener('click', saveDraft);
  $('btn-pick-file').addEventListener('click', pickFileAndParse);
  $('btn-paste-clip').addEventListener('click', async () => {
    const t = await window.api.readClipboard();
    if (!t) return toast('剪贴板为空', 'err');
    if (S.mode === 'link') $('input-url').value = t.trim();
    else $('input-text').value = t;
    toast('已读取剪贴板', 'ok', 1500);
  });
  $('input-url').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') doCapture();
  });

  // 分类管理
  $('btn-manage-cat').addEventListener('click', () => {
    renderCatManager();
    openModal('cat-modal');
  });
  $('btn-add-cat').addEventListener('click', async () => {
    const name = $('cat-name').value.trim();
    if (!name) return toast('请输入分类名称', 'err');
    const r = await window.api.addCategory({ name, parentId: Number($('cat-parent').value) || 0 });
    if (!r.ok) return toast(r.error, 'err');
    $('cat-name').value = '';
    renderCatManager();
    toast('分类已创建', 'ok', 1500);
  });

  // 检查更新
  $('btn-scan').addEventListener('click', async () => {
    toast('开始扫描追踪中的内容…', '', 2000);
    const r = await window.api.scanAll();
    if (!r.ok) return toast(r.error, 'err');
    const s = r.summary || {};
    toast(`扫描完成：检查 ${s.checked || 0} 条，更新 ${s.changed || 0} 条，失败 ${s.failed || 0} 条`, 'ok', 3200);
  });

  // 导出
  $('btn-export-list').addEventListener('click', async () => {
    const items = filteredItems();
    if (!items.length) return toast('当前列表为空', 'err');
    const r = await window.api.exportMarkdown({ ids: items.map((i) => i.id), all: false });
    if (r.ok && !r.canceled) toast('已导出：' + r.path, 'ok');
    else if (!r.ok) toast(r.error, 'err');
  });

  // 设置
  $('btn-save-settings').addEventListener('click', saveSettings);
  $('btn-test-llm').addEventListener('click', async () => {
    const res = $('llm-test-result');
    res.className = 'status';
    res.textContent = '测试中…';
    const llm = {
      baseUrl: $('set-llm-url').value.trim(),
      apiKey: $('set-llm-key').value.trim(),
      model: $('set-llm-model').value.trim()
    };
    if (!llm.baseUrl || !llm.apiKey || !llm.model) {
      res.className = 'status err';
      res.textContent = '请先填写接口地址、模型和 Key';
      return;
    }
    const r = await window.api.testLLM(llm);
    if (r.ok) {
      res.className = 'status ok';
      res.textContent = '连接成功：' + (r.reply || 'ok');
    } else {
      res.className = 'status err';
      res.textContent = '失败：' + r.error;
    }
  });
  $('btn-open-datadir').addEventListener('click', () => window.api.openDataDir());
  $('btn-backup').addEventListener('click', async () => {
    const r = await window.api.exportBackup();
    if (r.ok && !r.canceled) toast('备份已保存：' + r.path, 'ok');
    else if (!r.ok) toast(r.error, 'err');
  });
  $('btn-restore').addEventListener('click', async () => {
    const ok = await confirmDialog('导入备份？', '将把备份中的知识合并到当前知识库（相同链接不重复导入）。', {
      okLabel: '导入'
    });
    if (!ok) return;
    const r = await window.api.importBackup({ mode: 'merge' });
    if (!r.ok) return toast('导入失败：' + r.error, 'err');
    if (r.canceled) return;
    toast(`导入完成：新增 ${r.result.added} 条`, 'ok');
  });
  $('btn-clear').addEventListener('click', async () => {
    const ok = await confirmDialog('清空全部知识？', '所有条目、笔记、版本记录都会被删除，不可恢复。建议先导出备份。', {
      okLabel: '清空',
      danger: true
    });
    if (!ok) return;
    await window.api.clearData();
    closeDetail();
    toast('已清空知识库', 'ok');
  });

  $('btn-open-dir').addEventListener('click', () => window.api.openDataDir());

  // 详情标签页
  document.querySelectorAll('#detail-tabs button').forEach((b) => {
    b.addEventListener('click', () => {
      S.tab = b.dataset.tab;
      renderDetail();
    });
  });

  // 快捷键
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key.toLowerCase() === 'f') {
      e.preventDefault();
      $('search').focus();
      $('search').select();
    }
    if (e.key === 'Escape') {
      const open = [...document.querySelectorAll('.modal-mask')].find((m) => !m.classList.contains('hidden'));
      if (open && open.id !== 'confirm-modal') open.classList.add('hidden');
      else if (!open && S.selectedId) closeDetail();
    }
    if (e.ctrlKey && e.key.toLowerCase() === 'n') {
      e.preventDefault();
      openAddModal();
    }
  });
}

function renderCatManager() {
  const cats = S.snapshot.categories;
  const list = $('cat-list');
  list.innerHTML = '';
  const roots = cats.filter((c) => c.parentId === 0);
  roots.forEach((c) => {
    list.appendChild(catLine(c, false));
    cats.filter((x) => x.parentId === c.id).forEach((ch) => list.appendChild(catLine(ch, true)));
  });
  if (!roots.length) list.innerHTML = '<p class="muted" style="padding:12px">还没有分类</p>';
}

function catLine(cat, isChild) {
  const row = document.createElement('div');
  row.className = 'cat-line';
  const nm = document.createElement('span');
  nm.className = 'nm' + (isChild ? ' child' : '');
  nm.textContent = (isChild ? '↳ ' : '') + cat.name;

  const rename = document.createElement('button');
  rename.className = 'mini';
  rename.textContent = '重命名';
  rename.addEventListener('click', async () => {
    const input = document.createElement('input');
    input.value = cat.name;
    row.replaceChild(input, nm);
    input.focus();
    const commit = async () => {
      const v = input.value.trim();
      if (v && v !== cat.name) {
        await window.api.updateCategory(cat.id, { name: v });
        toast('已重命名', 'ok', 1500);
      }
      renderCatManager();
    };
    input.addEventListener('blur', commit);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') input.blur();
    });
  });

  const del = document.createElement('button');
  del.className = 'mini';
  del.textContent = '删除';
  del.addEventListener('click', async () => {
    const ok = await confirmDialog('删除分类？', `「${cat.name}」下的知识会移到上级分类，内容不会丢失。`, {
      okLabel: '删除',
      danger: true
    });
    if (!ok) return;
    await window.api.deleteCategory(cat.id);
    renderCatManager();
  });

  row.appendChild(nm);
  row.appendChild(rename);
  row.appendChild(del);
  return row;
}

/* ---------------- 启动 ---------------- */
async function boot() {
  bindCloseButtons();
  bindEvents();

  window.api.onDataChanged(({ snapshot }) => applySnapshot(snapshot));
  window.api.onTrackerEvent((evt) => {
    if (evt.type === 'changed') toast(`「${evt.title}」来源有更新`, 'ok', 3200);
  });
  window.api.onClipboardFound(async ({ text }) => {
    const ok = await confirmDialog('检测到剪贴板链接', text.length > 120 ? text.slice(0, 120) + '…' : text, {
      okLabel: '录入这条'
    });
    if (ok) openAddModal(text);
  });
  window.api.onLog((l) => {
    if (l.level === 'error') toast(l.msg, 'err', 4000);
  });
  window.api.onMenuAction((action) => {
    if (action === 'add') openAddModal();
    if (action === 'export-all') window.api.exportMarkdown({ all: true }).then((r) => {
      if (r.ok && !r.canceled) toast('已导出：' + r.path, 'ok');
    });
  });

  const boot = await window.api.bootstrap();
  $('app-ver').textContent = 'v' + boot.info.version + ' · 本地知识库';
  applySnapshot(boot.snapshot);
  if (!S.snapshot.items.length) {
    $('empty-state').classList.remove('hidden');
  }
}

document.addEventListener('DOMContentLoaded', boot);
