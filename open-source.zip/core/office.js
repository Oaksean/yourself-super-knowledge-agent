'use strict';
/**
 * Office 文档解析（.docx / .xlsx）——不引入第三方依赖。
 * 思路：Office 新格式本质是 zip + XML，这里自己读 zip 中央目录、用 zlib 解压，
 * 再从 document.xml / sheet.xml 里取文本与超链接目标。
 * 旧格式 .doc / .xls 为二进制复合文档，不在支持范围内（会给出明确提示）。
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const SIG_EOCD = 0x06054b50;
const SIG_CEN = 0x02014b50;
const SIG_LOCAL = 0x04034b50;

function decodeEntities(s) {
  return String(s)
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (m, d) => String.fromCharCode(Number(d)))
    .replace(/&#x([0-9a-fA-F]+);/g, (m, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/&amp;/g, '&');
}

function stripTags(xml) {
  return decodeEntities(String(xml).replace(/<[^>]*>/g, ''));
}

/** 读 zip：返回 { 文件名: 内容文本 } */
function readZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i > buf.length - 22 - 65536; i--) {
    if (buf.readUInt32LE(i) === SIG_EOCD) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error('不是有效的 Office 文件（zip 目录缺失）');
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const entries = {};
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(off) !== SIG_CEN) break;
    const method = buf.readUInt16LE(off + 10);
    const compSize = buf.readUInt32LE(off + 20);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    const name = buf.slice(off + 46, off + 46 + nameLen).toString('utf8');
    if (compSize === 0xffffffff || localOff === 0xffffffff) throw new Error('暂不支持 zip64 格式的超大 Office 文件');
    if (buf.readUInt32LE(localOff) === SIG_LOCAL) {
      const lNameLen = buf.readUInt16LE(localOff + 26);
      const lExtraLen = buf.readUInt16LE(localOff + 28);
      const start = localOff + 30 + lNameLen + lExtraLen;
      const raw = buf.slice(start, start + compSize);
      let data = null;
      try {
        if (method === 0) data = raw;
        else if (method === 8) data = zlib.inflateRawSync(raw);
      } catch (e) {
        data = null;
      }
      if (data) entries[name] = data.toString('utf8');
    }
    off += 46 + nameLen + extraLen + commentLen;
  }
  return entries;
}

/** .rels 里的外部超链接目标 */
function externalTargets(relsXml) {
  const out = [];
  const re = /<Relationship[^>]*?Target="([^"]+)"[^>]*?>/g;
  let m;
  while ((m = re.exec(relsXml || ''))) {
    const tag = m[0];
    if (/TargetMode="External"/i.test(tag) && /^https?:\/\//i.test(m[1])) out.push(decodeEntities(m[1]));
  }
  return out;
}

function docxToText(xml) {
  let s = String(xml)
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<w:instrText[\s\S]*?<\/w:instrText>/g, '')
    .replace(/<w:tab[^>]*\/>/g, '\t')
    .replace(/<w:br[^>]*\/>/g, '\n')
    .replace(/<\/w:tc>/g, ' | ')
    .replace(/<\/w:tr>/g, '\n')
    .replace(/<\/w:p>/g, '\n');
  s = stripTags(s);
  return s
    .replace(/[ \t]+/g, ' ')
    .replace(/ ?\n ?/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** 共享字符串表 */
function xlsxSharedStrings(xml) {
  const list = [];
  const re = /<si>([\s\S]*?)<\/si>/g;
  let m;
  while ((m = re.exec(xml || ''))) list.push(stripTags(m[1]).trim());
  return list;
}

function colIndex(ref) {
  const letters = String(ref || '').replace(/[^A-Z]/g, '');
  let n = 0;
  for (const ch of letters) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n ? n - 1 : 0;
}

/** 工作表 → 按行输出的文本（列用制表符分隔） */
function xlsxSheetToText(xml, shared) {
  const lines = [];
  const rowRe = /<row[^>]*>([\s\S]*?)<\/row>/g;
  let rm;
  while ((rm = rowRe.exec(xml || ''))) {
    const cells = [];
    const cellRe = /<c([^>]*)>([\s\S]*?)<\/c>/g;
    let cm;
    while ((cm = cellRe.exec(rm[1]))) {
      const attrs = cm[1] || '';
      const body = cm[2] || '';
      const refM = /r="([A-Z]+\d+)"/.exec(attrs);
      const idx = refM ? colIndex(refM[1]) : cells.length;
      const tM = /t="([^"]+)"/.exec(attrs);
      const type = tM ? tM[1] : '';
      let val = '';
      if (type === 's') {
        const vM = /<v>([\s\S]*?)<\/v>/.exec(body);
        const i = vM ? Number(vM[1]) : NaN;
        val = shared[i] || '';
      } else if (type === 'inlineStr') {
        val = stripTags(body).trim();
      } else {
        const vM = /<v>([\s\S]*?)<\/v>/.exec(body);
        val = vM ? decodeEntities(vM[1]) : '';
      }
      while (cells.length < idx) cells.push('');
      cells[idx] = String(val).replace(/\s+/g, ' ').trim();
    }
    const line = cells.join('\t').replace(/\t+$/, '');
    if (line.trim()) lines.push(line);
  }
  return lines.join('\n');
}

function readOfficeFile(filePath) {
  const ext = path.extname(String(filePath || '')).toLowerCase();
  if (ext === '.doc' || ext === '.xls') {
    throw new Error('旧版 .doc / .xls 是二进制格式，暂不支持；请在 Word/Excel 里另存为 .docx / .xlsx 后再导入');
  }
  if (ext !== '.docx' && ext !== '.xlsx') throw new Error('只支持 .docx 与 .xlsx 文件');
  const buf = fs.readFileSync(filePath);
  if (!buf.length) throw new Error('文件是空的');
  const zip = readZip(buf);
  const fileName = path.basename(filePath);

  if (ext === '.docx') {
    const doc = zip['word/document.xml'];
    if (!doc) throw new Error('这个 .docx 里没有正文（可能已损坏）');
    const text = docxToText(doc);
    const rels = zip['word/_rels/document.xml.rels'] || '';
    return {
      kind: 'docx',
      fileName,
      filePath,
      text,
      hyperlinks: externalTargets(rels),
      detail: `${text.length} 字`
    };
  }

  const shared = xlsxSharedStrings(zip['xl/sharedStrings.xml'] || '');
  const sheetNames = Object.keys(zip)
    .filter((n) => /^xl\/worksheets\/sheet\d+\.xml$/.test(n))
    .sort();
  if (!sheetNames.length) throw new Error('这个 .xlsx 里没有工作表（可能已损坏）');
  const blocks = [];
  const links = [];
  sheetNames.slice(0, 6).forEach((name, i) => {
    const sheetText = xlsxSheetToText(zip[name], shared);
    if (sheetText) blocks.push(`【工作表 ${i + 1}】\n${sheetText}`);
    const relName = name.replace(/worksheets\/(sheet\d+\.xml)$/, 'worksheets/_rels/$1.rels');
    links.push(...externalTargets(zip[relName] || ''));
  });
  const text = blocks.join('\n\n').trim();
  if (!text) throw new Error('表格里没有可提取的文字（可能只有图片或空表）');
  return {
    kind: 'xlsx',
    fileName,
    filePath,
    text,
    hyperlinks: links,
    detail: `${sheetNames.length} 个工作表 / ${text.length} 字`
  };
}

module.exports = { readOfficeFile, readZip, docxToText, xlsxSheetToText, xlsxSharedStrings };
