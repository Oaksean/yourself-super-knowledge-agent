'use strict';
/**
 * 摘要提炼：优先调用用户配置的大模型（OpenAI 兼容接口），
 * 未配置或调用失败时，使用纯本地抽取式摘要，保证离线可用。
 */

const STOP_WORDS = new Set(
  (
    '的 了 和 是 在 我 有 就 不 人 都 一 一个 上 也 很 到 说 要 去 你 会 着 没有 看 好 这 那 他 她 它 们 ' +
    '我们 你们 他们 自己 这个 那个 这些 那些 什么 怎么 为什么 可以 可能 应该 需要 但是 因为 所以 如果 虽然 ' +
    'and or of to in for on with is are was were be been the a an as by at from that this these those it its ' +
    'we you they he she i not no but if then than so such can could should would will may might do does did ' +
    'have has had more most less much many other another also there their our your my me us them ' +
    '本文 文章 作者 内容 方法 问题 情况 时间 时候 目前 已经 通过 以及 对于 关于 其中 进行 相关 一些 这种 这样 ' +
    '觉得 认为 表示 发现 看到 知道 希望 喜欢 觉得 比较 非常 特别 其实 真的 还是 只是 已经 并且 而且 或者 然后 ' +
    '这里 那里 上面 下面 之前 之后 现在 今天 明天 昨天 大家 别人 东西 事情 地方 方式 方面 结果 原因'
  )
    .split(/\s+/)
    .filter(Boolean)
);

const CATEGORY_RULES = [
  {
    name: 'AI与大模型',
    kws: ['ai', '大模型', 'llm', 'gpt', '模型', '训练', '推理', 'prompt', '智能体', 'agent', 'transformer', '神经网络', '向量', '微调', 'embedding', '多模态', '算力']
  },
  {
    name: '前端与工程',
    kws: ['前端', 'react', 'vue', 'flutter', 'css', 'html', 'javascript', 'typescript', '组件', '页面', '接口', '后端', '数据库', '架构', '部署', '服务', '代码', '工程', '重构', '性能']
  },
  {
    name: '机器人与航天',
    kws: ['机器人', '火箭', '发动机', '航天', '卫星', '传感器', '电机', '控制', '姿态', '推力', '轨道', '无人机', '机械臂']
  },
  {
    name: '工具与效率',
    kws: ['工具', '插件', '效率', '教程', '配置', '快捷键', '软件', '脚本', '自动化', '工作流', '模板', '技巧']
  },
  {
    name: '阅读与随笔',
    kws: ['读书', '思考', '随笔', '观点', '评论', '感悟', '笔记', '书评', '心得']
  }
];

function splitSentences(text) {
  const raw = String(text || '').replace(/\r/g, '');
  const parts = raw.split(/(?<=[。！？!?；;])|\n+/).map((p) => p.replace(/\s+/g, ' ').trim());
  // 英文长段落常被换行切断：上一段没有句末标点且下一段以小写开头时，先拼回去
  const merged = [];
  for (const p of parts) {
    if (!p) continue;
    const prev = merged.length ? merged[merged.length - 1] : '';
    if (prev && /^[a-z0-9("']/.test(p) && !/[。！？.!?；;:：]$/.test(prev) && (prev + ' ' + p).length <= 320) {
      merged[merged.length - 1] = prev + ' ' + p;
    } else {
      merged.push(p);
    }
  }
  const out = [];
  for (const p of merged) {
    const s = p;
    if (s.length < 8) continue;
    if (s.length > 200) {
      // 超长句按逗号再切
      s.split(/(?<=[，,])/).forEach((x) => {
        const t = x.trim();
        if (t.length >= 8) out.push(t);
      });
    } else {
      out.push(s);
    }
  }
  return out;
}

function tokenize(sentence) {
  const tokens = [];
  const lower = sentence.toLowerCase();
  const en = lower.match(/[a-z][a-z0-9+#.-]{1,}/g);
  if (en) en.forEach((w) => tokens.push(w));
  // 中文按 2-gram
  const cjkRuns = sentence.match(/[\u4e00-\u9fa5]+/g) || [];
  for (const run of cjkRuns) {
    if (run.length === 1) continue;
    for (let i = 0; i < run.length - 1; i++) tokens.push(run.slice(i, i + 2));
    if (run.length >= 4) {
      for (let i = 0; i < run.length - 2; i++) tokens.push(run.slice(i, i + 3));
    }
  }
  return tokens;
}

function isStop(token) {
  if (STOP_WORDS.has(token)) return true;
  if (token.length === 2 && STOP_WORDS.has(token[0])) return true;
  return false;
}

function scoreSentences(sentences) {
  const freq = new Map();
  const docs = sentences.map((s) => tokenize(s));
  docs.forEach((tokens) => {
    tokens.forEach((t) => {
      if (isStop(t)) return;
      freq.set(t, (freq.get(t) || 0) + 1);
    });
  });
  const scored = sentences.map((s, i) => {
    const tokens = docs[i];
    let sum = 0;
    tokens.forEach((t) => {
      if (isStop(t)) return;
      sum += (freq.get(t) || 0) * (t.length >= 3 ? 1.6 : 1);
    });
    const lenFactor = Math.pow(Math.max(tokens.length, 1), 0.6);
    const posBonus = 1 / (i + 2) * 2.2;
    const rel = i / Math.max(sentences.length, 1);
    const earlyBonus = rel < 0.12 ? 3.5 : rel < 0.3 ? 1.2 : 0;
    const numPenalty = /^(图|表|资料来源|责任编辑|版权)/.test(s) ? -3 : 0;
    // 小写开头的英文片段（上一句被切断的残留）通常不是完整信息
    const fragmentPenalty = /^[a-z]/.test(s) ? -2 : 0;
    // 语言切换条、多竖线表格行之类的页面装饰
    const chromePenalty =
      ((s.match(/\|/g) || []).length >= 3 ? -4 : 0) +
      (/^(English|简体中文|繁體中文|Español|日本語)/.test(s) ? -4 : 0);
    // 代码/命令片段（README 里很常见）不进摘要
    const codePenalty = /[{}`]|^shell |^pip |^import |^from |"""|^\$ |>=\s|^# /.test(s) ? -3 : 0;
    // 含具体数字、英文专名、冒号结论的句子通常是关键信息，加权
    const factBonus =
      (/[0-9]/.test(s) ? 1.8 : 0) +
      (/([A-Za-z][A-Za-z0-9.+#-]{2,})/.test(s) ? 1.0 : 0) +
      (/[：:]/.test(s) ? 0.5 : 0) +
      (/(提升|下降|增长|降低|达到|超过|版本|发布|开源|成本|性能)/.test(s) ? 0.8 : 0);
    return {
      i,
      s,
      score:
        sum / lenFactor + posBonus + earlyBonus + numPenalty + fragmentPenalty + chromePenalty + codePenalty + factBonus
    };
  });
  return scored.sort((a, b) => b.score - a.score);
}

function keywords(sentences, limit = 8) {
  const freq = new Map();
  sentences.forEach((s) => {
    tokenize(s).forEach((t) => {
      if (isStop(t)) return;
      if (t.length < 2) return;
      if (/^[\d.]+$/.test(t)) return;
      freq.set(t, (freq.get(t) || 0) + 1);
    });
  });
  const sorted = [...freq.entries()]
    .filter(([t, c]) => c >= 2 || (/[a-z]/.test(t) && t.length >= 3 && c >= 1))
    .sort((a, b) => b[1] - a[1]);

  const picked = [];
  for (const [t] of sorted) {
    if (picked.length >= limit) break;
    if (picked.some((p) => p.includes(t) || t.includes(p))) continue;
    picked.push(t);
  }
  return picked;
}

function guessCategory(title, text) {
  const hay = (title + ' ' + text).toLowerCase();
  let best = { name: '其他', hits: 0 };
  for (const rule of CATEGORY_RULES) {
    let hits = 0;
    rule.kws.forEach((kw) => {
      if (/^[a-z0-9+#.]+$/.test(kw)) {
        // 英文关键词按词边界匹配，避免 domain 命中 ai
        const re = new RegExp('(^|[^a-z0-9])' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^a-z0-9]|$)', 'gi');
        const m = hay.match(re);
        if (m) hits += m.length;
      } else {
        const parts = hay.split(kw).length - 1;
        if (parts > 0) hits += parts;
      }
    });
    if (hits > best.hits) best = { name: rule.name, hits };
  }
  return best.hits >= 2 ? best.name : '其他';
}

function trimTo(text, max) {
  if (text.length <= max) return text;
  const cut = text.slice(0, max);
  const lastStop = Math.max(cut.lastIndexOf('。'), cut.lastIndexOf('；'), cut.lastIndexOf('！'));
  return (lastStop > max * 0.6 ? cut.slice(0, lastStop + 1) : cut + '…').trim();
}

/** GitHub README 专用：跳过徽章/代码/语言切换条，只取开头几段真正的说明文字 */
function githubReadmeSummary(sentences) {
  const cleanish = (s) =>
    (s.match(/\|/g) || []).length <= 2 &&
    !/[{}`]|^shell |^pip |^import |^from |"""|=>|^\$ |^#|^TIP|^NOTE/.test(s) &&
    (s.match(/[A-Za-z\u4e00-\u9fa5]/g) || []).length / Math.max(s.length, 1) > 0.6;
  const isProse = (s) => s.length >= 60 && cleanish(s) && (s.match(/[A-Za-z]{2,}/g) || []).length >= 6;
  // 优先找「这是什么项目」类陈述句（README 开头通常有一句）
  const intro = sentences.slice(0, Math.max(14, Math.floor(sentences.length * 0.25))).filter(
    (s) =>
      s.length >= 50 &&
      cleanish(s) &&
      /(is a[n]?|provides|is the official|library|framework|toolkit|工具库|框架|提供|用于|是一款)/i.test(s)
  );
  const prose = intro.length >= 1 ? intro : sentences.filter(isProse);
  if (!prose.length) return { summary: '', used: new Set() };
  const out = [];
  const used = new Set();
  let len = 0;
  for (const s of prose) {
    if (len + s.length > 380) break;
    out.push(s);
    used.add(s);
    len += s.length;
    if (out.length >= 4) break;
  }
  return { summary: out.join(' '), used };
}

function summarizeLocal({ title, text, sourceType }) {
  const clean = String(text || '')
    .replace(/\s+/g, ' ')
    .trim();
  const sentences = splitSentences(clean);
  if (sentences.length === 0) {
    return {
      title: title || '文本片段',
      summary: clean.slice(0, 200) || '（内容为空）',
      keyPoints: [],
      tags: [],
      category: guessCategory(title || '', clean),
      summarySource: 'local',
      warning: '原文过短，未生成结构化摘要'
    };
  }
  const ranked = scoreSentences(sentences);
  // GitHub README：直接用开头几段说明性文字做摘要，比关键词打分更贴近「这是什么项目」
  if (sourceType === 'github') {
    const gh = githubReadmeSummary(sentences);
    if (gh.summary) {
      const rest = sentences.filter((s) => !gh.used.has(s));
      const keyPoints = rest
        .filter((s) => s.length >= 20 && !/[{}`]|"""|=>/.test(s))
        .slice(0, 5)
        .map((s) => trimTo(s.replace(/[。；]$/, ''), 90));
      return {
        title: title || sentences[0].slice(0, 30),
        summary: trimTo(gh.summary, 380),
        keyPoints,
        tags: keywords(sentences, 7),
        category: guessCategory(title || '', clean),
        summarySource: 'local'
      };
    }
  }
  // 英文片段（小写开头）不适合当摘要首句：句子足够多时直接剔除
  const candidates = sentences.length > 8 ? ranked.filter((p) => !/^[a-z]/.test(p.s)) : ranked;
  const pool = candidates.length >= 3 ? candidates : ranked;
  const topN = Math.min(clean.length > 3000 ? 8 : clean.length > 1500 ? 6 : 4, pool.length);
  const picked = pool.slice(0, topN).sort((a, b) => a.i - b.i);
  // 若入选句子里没有一条含数字/专名，补一条（关键数据往往是用户最想看的）
  const hasFact = picked.some((p) => /[0-9]/.test(p.s) || /[A-Za-z]{3,}/.test(p.s));
  if (!hasFact) {
    const fact = ranked.find((p) => /[0-9]/.test(p.s) || /[A-Za-z]{3,}/.test(p.s));
    if (fact && fact.s.length > 20 && !picked.some((p) => p.i === fact.i)) {
      picked.pop();
      picked.push(fact);
      picked.sort((a, b) => a.i - b.i);
    }
  }

  // 去重：同一段话在页面里重复出现时只保留一次
  const dedup = (arr) => {
    const seen = new Set();
    const out = [];
    arr.forEach((p) => {
      const key = p.s.replace(/[\s，。；、,.!?！？"“”【】()（）\[\]]/g, '').slice(0, 60);
      if (!key || seen.has(key)) return;
      seen.add(key);
      out.push(p);
    });
    return out;
  };
  const pickedUniq = dedup(picked);
  let summary = pickedUniq.map((p) => p.s).join(' ');
  summary = trimTo(summary, 380);

  const used = new Set(pickedUniq.map((p) => p.i));
  let extra = ranked.filter((p) => !used.has(p.i));
  if (extra.length < 2) extra = ranked;
  const keyPoints = dedup(extra)
    .slice(0, Math.min(5, sentences.length))
    .sort((a, b) => a.i - b.i)
    .map((p) => trimTo(p.s.replace(/[。；]$/, ''), 90));

  const tagWords = keywords(sentences, 7);

  return {
    title: title || sentences[0].slice(0, 30),
    summary,
    keyPoints,
    tags: tagWords,
    category: guessCategory(title || '', clean),
    summarySource: 'local'
  };
}

function safeJsonParse(raw) {
  if (!raw) return null;
  let s = String(raw).trim();
  s = s.replace(/^```[a-zA-Z]*\s*/, '').replace(/```$/, '').trim();
  const start = s.indexOf('{');
  const end = s.lastIndexOf('}');
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    return JSON.parse(s.slice(start, end + 1));
  } catch (e) {
    return null;
  }
}

async function summarizeByLLM({ title, text }, llm) {
  const base = String(llm.baseUrl || '').replace(/\/+$/, '');
  const endpoint = /\/chat\/completions$/.test(base) ? base : base + '/chat/completions';
  const body = {
    model: llm.model,
    temperature: typeof llm.temperature === 'number' ? llm.temperature : 0.2,
    messages: [
      {
        role: 'system',
        content:
          '你是严谨的中文信息提炼助手。只输出 JSON，不要输出任何解释、不要加代码块标记。字段必须齐全。'
      },
      {
        role: 'user',
        content: `请阅读下面的内容并提炼，严格输出 JSON：
{"title":"标题","summary":"250-400字的核心摘要。必须写出：它是什么/解决了什么问题、关键做法或机制、具体结论或数据（数字、版本、指标保留原值），不要空话套话，不要复述标题","keyPoints":["4-6条关键信息，每条不超过60字，优先写具体事实：名称、数字、版本、结论、步骤；不要写“本文介绍了”这类空话"],"tags":["3-6个名词性标签"],"category":"从这些分类里选一个最贴切的：AI与大模型、前端与工程、机器人与航天、工具与效率、阅读与随笔、其他"}

【原文标题】${title || '(无)'}
【原文内容】
${String(text || '').slice(0, 6000)}`
      }
    ]
  };
  const resp = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${llm.apiKey}`
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(60000)
  });
  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`模型接口返回 ${resp.status}：${errText.slice(0, 200)}`);
  }
  const json = await resp.json();
  const content =
    (json.choices && json.choices[0] && json.choices[0].message && json.choices[0].message.content) || '';
  const parsed = safeJsonParse(content);
  if (!parsed) throw new Error('模型没有返回合法 JSON，已回退本地摘要');
  return {
    title: parsed.title || title,
    summary: String(parsed.summary || '').trim() || summarizeLocal({ title, text }).summary,
    keyPoints: Array.isArray(parsed.keyPoints) ? parsed.keyPoints.slice(0, 8).map(String) : [],
    tags: Array.isArray(parsed.tags) ? parsed.tags.slice(0, 8).map(String) : [],
    category: parsed.category || guessCategory(title || '', text),
    summarySource: 'llm'
  };
}

/** 通用「让模型返回 JSON」调用，供文档解析等场景复用 */
async function chatJSON(llm, system, user, timeoutMs = 60000) {
  const base = String(llm.baseUrl || '').replace(/\/+$/, '');
  const endpoint = /\/chat\/completions$/.test(base) ? base : base + '/chat/completions';
  const resp = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${llm.apiKey}` },
    body: JSON.stringify({
      model: llm.model,
      temperature: typeof llm.temperature === 'number' ? llm.temperature : 0.2,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user }
      ]
    }),
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!resp.ok) {
    const t = await resp.text();
    throw new Error(`模型接口返回 ${resp.status}：${t.slice(0, 200)}`);
  }
  const j = await resp.json();
  const content = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '';
  const parsed = safeJsonParse(content);
  if (!parsed) throw new Error('模型没有返回合法 JSON');
  return parsed;
}

const DOC_LINK_RANK = { github: 0, huggingface: 1, modelscope: 2, gitee: 3, arxiv: 4, paper: 5, other: 6 };

/** 没接大模型时的兜底：按平台价值挑链接 */
function pickDocumentLinks(list, n) {
  const seen = new Set();
  const uniq = [];
  (list || []).forEach((l) => {
    const u = String((l && l.url) || '').trim();
    if (!u || seen.has(u)) return;
    seen.add(u);
    uniq.push(l);
  });
  uniq.sort((a, b) => (DOC_LINK_RANK[a.kind] === undefined ? 9 : DOC_LINK_RANK[a.kind]) - (DOC_LINK_RANK[b.kind] === undefined ? 9 : DOC_LINK_RANK[b.kind]));
  return uniq.slice(0, n);
}

/**
 * 文档（Word / Excel）解析：正文提炼 + 从候选链接里挑出值得继续抓取的
 * @param {{fileName:string, text:string, candidates:Array}} input
 */
async function analyzeDocument({ fileName, text, candidates }, llmSettings) {
  const body = String(text || '');
  const cand = Array.isArray(candidates) ? candidates : [];
  const local = () => {
    const base = summarizeLocal({ title: fileName, text: body, sourceType: 'file' });
    return {
      title: base.title,
      summary: base.summary,
      keyPoints: base.keyPoints,
      tags: (base.tags || []).slice(0, 6),
      category: base.category,
      links: pickDocumentLinks(cand, 5),
      summarySource: 'local'
    };
  };
  const llm = llmSettings || {};
  if (!(llm.enabled && llm.apiKey && llm.model && llm.baseUrl)) return local();
  try {
    const candText = cand.length
      ? cand.map((c, i) => `${i + 1}. ${c.url}`).join('\n')
      : '(文档里没有发现链接)';
    const parsed = await chatJSON(
      llm,
      '你是严谨的中文文档解析助手。只输出 JSON，不要解释、不要代码块。',
      `请解析下面这份文档，严格输出 JSON：
{"title":"文档标题（优先用文档里最像标题的一行，没有就用文件名）","summary":"250-400字：这份文档讲了什么、关键结论或数据（数字/版本/指标保留原值），不要空话","keyPoints":["4-6条关键信息，每条≤60字，写具体事实"],"tags":["3-6个名词性标签"],"category":"从这些分类里选一个最贴切的：AI与大模型、前端与工程、机器人与航天、工具与效率、阅读与随笔、其他","links":["从下面候选链接里挑出最值得进一步抓取学习的 URL，最多 5 条；必须原样复制候选里出现的完整 URL，不要编造、不要改写、不要拼接"]}

【文件名】${fileName || '(未知)'}
【候选链接】
${candText}
【文档正文】
${body.slice(0, 8000)}`
    );
    const valid = [];
    (Array.isArray(parsed.links) ? parsed.links : []).forEach((u) => {
      const s = String(u || '').trim();
      if (!s) return;
      const hit = cand.find((c) => String(c.url).replace(/\/+$/, '') === s.replace(/\/+$/, ''));
      if (hit && !valid.some((v) => v.url === hit.url)) valid.push(hit);
    });
    const picked = valid.length ? valid.slice(0, 5) : pickDocumentLinks(cand, 4);
    return {
      title: String(parsed.title || fileName || '').trim() || fileName,
      summary: String(parsed.summary || '').trim() || local().summary,
      keyPoints: Array.isArray(parsed.keyPoints) ? parsed.keyPoints.slice(0, 8).map(String) : local().keyPoints,
      tags: Array.isArray(parsed.tags) ? parsed.tags.slice(0, 8).map(String) : local().tags,
      category: parsed.category || local().category,
      links: picked,
      summarySource: 'llm'
    };
  } catch (e) {
    const f = local();
    f.warning = '大模型解析失败，已用本地解析：' + e.message;
    return f;
  }
}

async function summarize({ title, text, sourceType }, llmSettings) {  const llm = llmSettings || {};
  if (llm.enabled && llm.apiKey && llm.model && llm.baseUrl) {
    try {
      return await summarizeByLLM({ title, text }, llm);
    } catch (e) {
      const local = summarizeLocal({ title, text, sourceType });
      local.warning = '大模型调用失败，已使用本地摘要：' + e.message;
      return local;
    }
  }
  return summarizeLocal({ title, text, sourceType });
}

/* ---------------- 分类归类总结（知识树） ---------------- */

function aggregateLocal({ categoryName, items }) {
  const list = (items || []).slice();
  if (!list.length) {
    return { summary: '该分类下还没有内容。', keyPoints: [], tags: [], summarySource: 'local' };
  }
  const tagFreq = {};
  list.forEach((it) => (it.tags || []).forEach((t) => (tagFreq[t] = (tagFreq[t] || 0) + 1)));
  const topTags = Object.entries(tagFreq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map((x) => x[0]);

  const corpus = list.map((it) => `${it.title || ''}。${it.summary || ''}`).join('。');
  const topics = keywords(splitSentences(corpus.replace(/\n/g, '。')), 8).filter((t) => t.length >= 2);

  const times = list.map((i) => i.createAt || '').filter(Boolean).sort();
  const span = times.length ? `${times[0].slice(0, 10)} ~ ${times[times.length - 1].slice(0, 10)}` : '';

  const samples = [];
  list.slice(0, 4).forEach((it) => {
    const p = (it.keyPoints || [])[0];
    if (p && p.length > 8 && !samples.some((s) => s.slice(0, 12) === p.slice(0, 12))) samples.push(p);
  });

  const lines = [];
  lines.push(`「${categoryName || '未分类'}」下共 ${list.length} 条知识${span ? `，时间跨度 ${span}` : ''}。`);
  const themeWords = topTags.length ? topTags : topics.slice(0, 5);
  if (themeWords.length) lines.push(`主题集中在：${themeWords.join('、')}。`);
  if (samples.length) lines.push(`共同要点：${samples.slice(0, 3).map((s) => trimTo(s, 46)).join('；')}。`);
  const latest = list.slice().sort((a, b) => (a.createAt < b.createAt ? 1 : -1))[0];
  if (latest && latest.title) {
    lines.push(`建议先读最新一篇《${trimTo(latest.title, 30)}》，再按时间回溯同主题的早期内容。`);
  }

  return {
    summary: lines.join(' '),
    keyPoints: samples.slice(0, 3),
    tags: topTags,
    summarySource: 'local'
  };
}

async function summarizeCategory({ categoryName, items }, llmSettings) {
  const list = (items || []).slice(0, 40);
  const llm = llmSettings || {};
  if (llm.enabled && llm.apiKey && llm.model && llm.baseUrl && list.length) {
    try {
      const base = String(llm.baseUrl || '').replace(/\/+$/, '');
      const endpoint = /\/chat\/completions$/.test(base) ? base : base + '/chat/completions';
      const digest = list
        .map((it, i) => `${i + 1}. ${it.title || ''}｜${(it.tags || []).join('/')}｜${trimTo(it.summary || '', 110)}`)
        .join('\n');
      const body = {
        model: llm.model,
        temperature: 0.3,
        messages: [
          { role: 'system', content: '你是知识管理助手，只输出 JSON，不加代码块标记。' },
          {
            role: 'user',
            content: `下面是知识库中「${categoryName || '未分类'}」分类下的条目。请做归类总结，帮读者建立这一块的体系认知，严格输出 JSON：
{"summary":"200-320字：这批内容整体在讲什么、分成哪几个子主题、彼此是什么关系、能得出什么共性结论","keyPoints":["3-5条这个分类的知识主线或学习要点，每条不超过50字"],"tags":["4-8个覆盖全分类的主题词"]}

${digest}`
          }
        ]
      };
      const resp = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${llm.apiKey}` },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(60000)
      });
      if (!resp.ok) throw new Error('接口返回 ' + resp.status);
      const json = await resp.json();
      const content =
        (json.choices && json.choices[0] && json.choices[0].message && json.choices[0].message.content) || '';
      const parsed = safeJsonParse(content);
      if (!parsed || !parsed.summary) throw new Error('模型未返回合法 JSON');
      return {
        summary: String(parsed.summary).trim(),
        keyPoints: Array.isArray(parsed.keyPoints) ? parsed.keyPoints.slice(0, 5).map(String) : [],
        tags: Array.isArray(parsed.tags) ? parsed.tags.slice(0, 8).map(String) : [],
        summarySource: 'llm'
      };
    } catch (e) {
      const local = aggregateLocal({ categoryName, items });
      local.warning = '大模型归纳失败，已用本地归纳：' + e.message;
      return local;
    }
  }
  return aggregateLocal({ categoryName, items });
}

async function testLLM(llm) {
  const base = String(llm.baseUrl || '').replace(/\/+$/, '');
  const endpoint = /\/chat\/completions$/.test(base) ? base : base + '/chat/completions';
  const resp = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${llm.apiKey}` },
    body: JSON.stringify({
      model: llm.model,
      temperature: 0,
      messages: [{ role: 'user', content: '只回复两个字：可用' }]
    }),
    signal: AbortSignal.timeout(30000)
  });
  if (!resp.ok) {
    const t = await resp.text();
    throw new Error(`接口返回 ${resp.status}：${t.slice(0, 200)}`);
  }
  const j = await resp.json();
  const content = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
  return { ok: true, reply: String(content || '').slice(0, 100) };
}

module.exports = {
  summarize,
  summarizeLocal,
  analyzeDocument,
  pickDocumentLinks,
  summarizeCategory,
  aggregateLocal,
  testLLM,
  guessCategory,
  splitSentences
};
