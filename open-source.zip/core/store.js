'use strict';
/**
 * 本地数据仓库：单文件 JSON + 原子写入
 * 数据目录默认为 Electron userData，可用 setDataDir 覆盖
 */
const fs = require('fs');
const path = require('path');

const DEFAULT_SETTINGS = {
  llm: {
    enabled: false,
    baseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    apiKey: '',
    model: '',
    temperature: 0.2
  },
  githubToken: '',
  trackIntervalMinutes: 60,
  clipboardWatch: false,
  showUpdateBadge: true
};

const SEED_CATEGORIES = [
  { name: 'AI与大模型', sort: 1 },
  { name: '前端与工程', sort: 2 },
  { name: '机器人与航天', sort: 3 },
  { name: '工具与效率', sort: 4 },
  { name: '阅读与随笔', sort: 5 }
];

function nowIso() {
  return new Date().toISOString();
}

class Store {
  constructor(dataDir) {
    this.dataDir = dataDir;
    this.file = path.join(dataDir, 'data.json');
    this.tmpFile = path.join(dataDir, 'data.json.tmp');
    this.backupFile = path.join(dataDir, 'data.backup.json');
    this.data = null;
    this._load();
  }

  setDataDir(dir) {
    if (!dir || dir === this.dataDir) return;
    this.dataDir = dir;
    this.file = path.join(dir, 'data.json');
    this.tmpFile = path.join(dir, 'data.json.tmp');
    this.backupFile = path.join(dir, 'data.backup.json');
    this._load();
  }

  _defaultData() {
    const t = nowIso();
    return {
      version: 1,
      meta: { nextId: 1, nextCategoryId: 1 },
      items: [],
      categories: SEED_CATEGORIES.map((c) => ({
        id: this._nextCategoryIdRaw(),
        name: c.name,
        parentId: 0,
        sort: c.sort,
        createAt: t
      })),
      settings: JSON.parse(JSON.stringify(DEFAULT_SETTINGS))
    };
  }

  _nextCategoryIdRaw() {
    // 仅用于首次初始化，独立计数
    this.__seedId = (this.__seedId || 0) + 1;
    return this.__seedId;
  }

  _load() {
    try {
      fs.mkdirSync(this.dataDir, { recursive: true });
    } catch (e) {
      /* ignore */
    }
    let data = null;
    if (fs.existsSync(this.file)) {
      try {
        data = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      } catch (e) {
        // 主文件损坏时尝试备份
        try {
          data = JSON.parse(fs.readFileSync(this.backupFile, 'utf8'));
        } catch (e2) {
          data = null;
        }
      }
    }
    this.__seedId = 0;
    this.data = this._normalize(data || this._defaultData());
    if (!fs.existsSync(this.file)) this.save();
  }

  _normalize(raw) {
    const d = raw && typeof raw === 'object' ? raw : {};
    d.version = d.version || 1;
    d.items = Array.isArray(d.items) ? d.items : [];
    d.categories = Array.isArray(d.categories) ? d.categories : [];
    d.settings = Object.assign({}, DEFAULT_SETTINGS, d.settings || {});
    d.settings.llm = Object.assign({}, DEFAULT_SETTINGS.llm, (d.settings || {}).llm || {});
    d.categorySummaries = d.categorySummaries && typeof d.categorySummaries === 'object' ? d.categorySummaries : {};
    d.meta = d.meta || {};
    const maxItem = d.items.reduce((m, i) => Math.max(m, Number(i.id) || 0), 0);
    const maxCat = d.categories.reduce((m, c) => Math.max(m, Number(c.id) || 0), 0);
    d.meta.nextId = Math.max(Number(d.meta.nextId) || 1, maxItem + 1);
    d.meta.nextCategoryId = Math.max(Number(d.meta.nextCategoryId) || 1, maxCat + 1);
    // 补齐字段，兼容旧数据
    d.items = d.items.map((it) => ({
      id: Number(it.id),
      title: it.title || '(无标题)',
      sourceUrl: it.sourceUrl || '',
      sourceType: it.sourceType || 'web',
      summary: it.summary || '',
      keyPoints: Array.isArray(it.keyPoints) ? it.keyPoints : [],
      categoryId: Number(it.categoryId) || 0,
      tags: Array.isArray(it.tags) ? it.tags : [],
      note: it.note || '',
      createAt: it.createAt || nowIso(),
      updatedAt: it.updatedAt || it.createAt || nowIso(),
      lastCheckAt: it.lastCheckAt || null,
      enableTrack: !!it.enableTrack,
      trackIntervalHours: Number(it.trackIntervalHours) || 24,
      contentHash: it.contentHash || '',
      coverUrl: it.coverUrl || '',
      hasUpdate: !!it.hasUpdate,
      versions: Array.isArray(it.versions) ? it.versions : [],
      starred: !!it.starred,
      charCount: Number(it.charCount) || 0,
      links: Array.isArray(it.links) ? it.links.filter((l) => l && l.url) : []
    }));
    return d;
  }

  save() {
    const json = JSON.stringify(this.data, null, 2);
    try {
      fs.writeFileSync(this.tmpFile, json, 'utf8');
      if (fs.existsSync(this.file)) {
        try {
          fs.copyFileSync(this.file, this.backupFile);
        } catch (e) {
          /* ignore */
        }
      }
      fs.renameSync(this.tmpFile, this.file);
      return true;
    } catch (e) {
      // 极端情况下（文件被占用）直接覆盖
      try {
        fs.writeFileSync(this.file, json, 'utf8');
        return true;
      } catch (e2) {
        throw new Error('数据保存失败：' + e2.message);
      }
    }
  }

  // ---------- 读取 ----------
  getSettings() {
    return JSON.parse(JSON.stringify(this.data.settings));
  }

  getItems() {
    return this.data.items.slice().sort((a, b) => (a.createAt < b.createAt ? 1 : -1));
  }

  getItem(id) {
    return this.data.items.find((i) => i.id === Number(id)) || null;
  }

  getCategories() {
    return this.data.categories.slice().sort((a, b) => (a.sort - b.sort) || a.id - b.id);
  }

  snapshot() {
    const items = this.getItems();
    const categories = this.getCategories();
    const tags = {};
    items.forEach((it) => (it.tags || []).forEach((t) => (tags[t] = (tags[t] || 0) + 1)));
    return {
      items,
      categories,
      settings: this.getSettings(),
      stats: {
        total: items.length,
        tracking: items.filter((i) => i.enableTrack).length,
        updated: items.filter((i) => i.hasUpdate).length,
        tags: Object.keys(tags)
          .map((t) => ({ tag: t, count: tags[t] }))
          .sort((a, b) => b.count - a.count)
      },
      dataFile: this.file,
      categorySummaries: this.data.categorySummaries
    };
  }

  // ---------- 条目 ----------
  addItem(payload) {
    const id = this.data.meta.nextId++;
    const t = nowIso();
    const item = {
      id,
      title: payload.title || '(无标题)',
      sourceUrl: payload.sourceUrl || '',
      sourceType: payload.sourceType || 'web',
      summary: payload.summary || '',
      keyPoints: payload.keyPoints || [],
      categoryId: Number(payload.categoryId) || 0,
      tags: payload.tags || [],
      note: payload.note || '',
      createAt: t,
      updatedAt: t,
      lastCheckAt: t,
      enableTrack: !!payload.enableTrack,
      trackIntervalHours: Number(payload.trackIntervalHours) || 24,
      contentHash: payload.contentHash || '',
      coverUrl: payload.coverUrl || '',
      hasUpdate: false,
      versions: [],
      starred: false,
      charCount: Number(payload.charCount) || 0,
      links: Array.isArray(payload.links) ? payload.links : []
    };
    this.data.items.push(item);
    this.save();
    return item;
  }

  updateItem(id, patch) {
    const item = this.getItem(id);
    if (!item) return null;
    const allow = [
      'title', 'sourceUrl', 'sourceType', 'summary', 'keyPoints', 'categoryId',
      'tags', 'note', 'enableTrack', 'trackIntervalHours', 'hasUpdate', 'starred',
      'links',
      'contentHash', 'coverUrl', 'lastCheckAt', 'charCount'
    ];
    allow.forEach((k) => {
      if (patch[k] !== undefined) item[k] = patch[k];
    });
    item.updatedAt = nowIso();
    this.save();
    return item;
  }

  deleteItems(ids) {
    const set = new Set((ids || []).map(Number));
    this.data.items = this.data.items.filter((i) => !set.has(i.id));
    this.save();
    return true;
  }

  pushVersion(id, version) {
    const item = this.getItem(id);
    if (!item) return null;
    item.versions = item.versions || [];
    item.versions.unshift(Object.assign({ createAt: nowIso() }, version));
    if (item.versions.length > 30) item.versions.length = 30;
    this.save();
    return item;
  }

  // ---------- 分类 ----------
  addCategory({ name, parentId = 0 }) {
    const t = nowIso();
    const cat = {
      id: this.data.meta.nextCategoryId++,
      name: (name || '未命名分类').trim() || '未命名分类',
      parentId: Number(parentId) || 0,
      sort: this.data.categories.length + 1,
      createAt: t
    };
    this.data.categories.push(cat);
    this.save();
    return cat;
  }

  updateCategory(id, patch) {
    const cat = this.data.categories.find((c) => c.id === Number(id));
    if (!cat) return null;
    if (patch.name !== undefined) cat.name = String(patch.name).trim() || cat.name;
    if (patch.parentId !== undefined) {
      const pid = Number(patch.parentId) || 0;
      if (pid !== cat.id) cat.parentId = pid;
    }
    if (patch.sort !== undefined) cat.sort = Number(patch.sort) || 0;
    this.save();
    return cat;
  }

  deleteCategory(id) {
    const cid = Number(id);
    const cat = this.data.categories.find((c) => c.id === cid);
    if (!cat) return false;
    const fallback = cat.parentId || 0;
    // 子分类上移到父级，条目迁移到父级分类
    this.data.categories.forEach((c) => {
      if (c.parentId === cid) c.parentId = fallback;
    });
    this.data.items.forEach((i) => {
      if (i.categoryId === cid) i.categoryId = fallback;
    });
    this.data.categories = this.data.categories.filter((c) => c.id !== cid);
    this.save();
    return true;
  }

  // ---------- 设置 ----------
  updateSettings(patch) {
    const s = this.data.settings;
    Object.keys(patch || {}).forEach((k) => {
      if (k === 'llm') {
        s.llm = Object.assign({}, s.llm, patch.llm || {});
      } else if (k in s) {
        s[k] = patch[k];
      }
    });
    this.save();
    return this.getSettings();
  }

  // ---------- 分类归纳 ----------
  getCategorySummary(categoryId) {
    return this.data.categorySummaries[String(categoryId)] || null;
  }

  setCategorySummary(categoryId, payload) {
    this.data.categorySummaries[String(categoryId)] = Object.assign({ at: nowIso() }, payload);
    this.save();
    return this.data.categorySummaries[String(categoryId)];
  }

  // ---------- 导入导出 ----------
  exportAll() {
    return {
      app: '随手贴',
      version: 1,
      exportAt: nowIso(),
      items: this.data.items,
      categories: this.data.categories
    };
  }

  importAll(payload, mode = 'merge') {
    if (!payload || !Array.isArray(payload.items)) throw new Error('备份文件格式不正确');
    if (mode === 'replace') {
      this.data.items = [];
      this.data.categories = [];
      this.data.meta.nextId = 1;
      this.data.meta.nextCategoryId = 1;
    }
    const catMap = new Map();
    (payload.categories || []).forEach((c) => {
      const exists = this.data.categories.find((x) => x.name === c.name && x.parentId === (c.parentId || 0));
      if (exists) {
        catMap.set(c.id, exists.id);
      } else {
        const nc = this.addCategory({ name: c.name, parentId: 0 });
        catMap.set(c.id, nc.id);
      }
    });
    let added = 0;
    payload.items.forEach((raw) => {
      const dup = raw.sourceUrl
        ? this.data.items.find((i) => i.sourceUrl === raw.sourceUrl)
        : null;
      if (dup && mode !== 'replace') return;
      const id = this.data.meta.nextId++;
      const item = Object.assign({}, raw, {
        id,
        categoryId: catMap.get(raw.categoryId) || Number(raw.categoryId) || 0,
        versions: Array.isArray(raw.versions) ? raw.versions : []
      });
      this.data.items.push(item);
      added++;
    });
    this.save();
    return { added, categories: catMap.size };
  }

  clearAll() {
    this.data.items = [];
    this.save();
    return true;
  }
}

module.exports = { Store, DEFAULT_SETTINGS, nowIso };
