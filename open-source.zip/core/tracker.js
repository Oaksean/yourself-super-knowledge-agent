'use strict';
/**
 * 追踪器：按条目自身周期检查来源是否更新，变更则生成新版本摘要。
 * 全部在本地进程内运行，无需后端。
 */
const crypto = require('crypto');
const { nowIso } = require('./store');

function hashText(text) {
  return crypto.createHash('sha256').update(String(text || '')).digest('hex');
}

class Tracker {
  constructor({ store, fetcher, summarizer, onUpdate, onLog }) {
    this.store = store;
    this.fetcher = fetcher;
    this.summarizer = summarizer;
    this.onUpdate = onUpdate || (() => {});
    this.onLog = onLog || (() => {});
    this.timer = null;
    this.running = false;
  }

  start(intervalMinutes) {
    this.stop();
    const minutes = Math.max(1, Number(intervalMinutes) || 60);
    this.timer = setInterval(() => {
      this.checkDue().catch((e) => this.onLog({ level: 'error', msg: '定时追踪异常：' + e.message }));
    }, minutes * 60 * 1000);
    if (this.timer.unref) this.timer.unref();
    this.onLog({ level: 'info', msg: `追踪任务已启动，每 ${minutes} 分钟扫描一次` });
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  async checkItem(id, { force = false } = {}) {
    const item = this.store.getItem(id);
    if (!item) throw new Error('条目不存在');
    if (!item.sourceUrl) throw new Error('该条目没有来源链接，无法追踪');
    const settings = this.store.getSettings();
    const raw = await this.fetcher.fetchSource({
      url: item.sourceUrl,
      githubToken: settings.githubToken
    });
    const hash = hashText(raw.text);
    const changed = force || !item.contentHash || hash !== item.contentHash;

    let result = null;
    if (changed) {
      result = await this.summarizer.summarize(
        { title: raw.title || item.title, text: raw.text, sourceType: raw.sourceType },
        settings.llm
      );
      if (item.contentHash) {
        // 保存旧版本快照
        this.store.pushVersion(item.id, {
          summary: item.summary,
          keyPoints: item.keyPoints,
          contentHash: item.contentHash,
          title: item.title
        });
      }
      this.store.updateItem(item.id, {
        title: result.title || item.title,
        summary: result.summary,
        keyPoints: result.keyPoints,
        tags: (result.tags && result.tags.length ? result.tags : item.tags),
        contentHash: hash,
        hasUpdate: !!item.contentHash,
        lastCheckAt: nowIso(),
        charCount: raw.text.length,
        coverUrl: raw.coverUrl || item.coverUrl
      });
      this.onUpdate({ type: 'changed', id: item.id, title: item.title });
    } else {
      this.store.updateItem(item.id, { lastCheckAt: nowIso() });
      this.onUpdate({ type: 'unchanged', id: item.id, title: item.title });
    }
    return { changed, item: this.store.getItem(item.id), result };
  }

  async checkDue() {
    if (this.running) return { skipped: true };
    this.running = true;
    const settings = this.store.getSettings();
    const items = this.store.getItems().filter((i) => i.enableTrack && i.sourceUrl);
    const due = items.filter((i) => {
      if (!i.lastCheckAt) return true;
      const hours = Number(i.trackIntervalHours) || 24;
      return Date.now() - new Date(i.lastCheckAt).getTime() >= hours * 3600 * 1000;
    });
    const summary = { total: items.length, checked: 0, changed: 0, failed: 0 };
    for (const item of due) {
      try {
        const r = await this.checkItem(item.id);
        summary.checked++;
        if (r.changed) summary.changed++;
      } catch (e) {
        summary.failed++;
        this.onLog({ level: 'error', msg: `「${item.title}」检查失败：${e.message}` });
      }
      await new Promise((res) => setTimeout(res, 1200));
    }
    this.running = false;
    this.onUpdate(Object.assign({ type: 'scan', at: nowIso() }, summary));
    return summary;
  }
}

module.exports = { Tracker, hashText };
