'use strict';
/**
 * 导出：单条 Markdown / 分类 Markdown / 全库 Markdown / JSON 备份
 */
const fs = require('fs');
const path = require('path');
const { nowIso } = require('./store');

function fmt(dt) {
  if (!dt) return '';
  try {
    const d = new Date(dt);
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  } catch (e) {
    return String(dt);
  }
}

function categoryName(categories, id) {
  const c = (categories || []).find((x) => x.id === Number(id));
  return c ? c.name : '未分类';
}

function itemToMarkdown(item, categories) {
  const tags = (item.tags || []).join('、') || '无';
  const points = (item.keyPoints || []).length
    ? item.keyPoints.map((p) => `- ${p}`).join('\n')
    : '- （无）';
  const urlLine = item.sourceUrl ? `[${item.sourceUrl}](${item.sourceUrl})` : '无（手动录入文本）';
  const versions = (item.versions || [])
    .map((v) => `- ${fmt(v.createAt)}｜${(v.summary || '').slice(0, 60)}`)
    .join('\n');

  return `# ${item.title}

- 创建时间：${fmt(item.createAt)}
- 最后更新：${fmt(item.updatedAt)}
- 来源链接：${urlLine}
- 类型：${item.sourceType}
- 分类：${categoryName(categories, item.categoryId)}
- 标签：${tags}
- 追踪：${item.enableTrack ? '已开启' : '未开启'}

## AI 摘要

${item.summary || '（无）'}

## 核心要点

${points}

## 我的笔记

${item.note || '（暂无笔记）'}
${versions ? `\n## 历史版本\n\n${versions}\n` : ''}`;
}

function buildMarkdown(items, categories, { groupByCategory = false, title = '随手贴导出' } = {}) {
  const header = `> 由随手贴导出 · ${fmt(nowIso())} · 共 ${items.length} 条\n\n`;
  if (!groupByCategory) {
    return header + items.map((i) => itemToMarkdown(i, categories)).join('\n\n---\n\n');
  }
  const groups = new Map();
  items.forEach((i) => {
    const name = categoryName(categories, i.categoryId);
    if (!groups.has(name)) groups.set(name, []);
    groups.get(name).push(i);
  });
  let md = header + `# ${title}\n\n`;
  for (const [name, list] of groups) {
    md += `# ${name}（${list.length} 条）\n\n`;
    md += list.map((i) => itemToMarkdown(i, categories)).join('\n\n---\n\n');
    md += '\n\n';
  }
  return md;
}

function safeFileName(name) {
  return String(name || '导出')
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\s+/g, ' ')
    .slice(0, 60);
}

function writeFile(filePath, content) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, content, 'utf8');
  return { path: filePath, bytes: Buffer.byteLength(content, 'utf8') };
}

module.exports = { itemToMarkdown, buildMarkdown, writeFile, safeFileName, fmt };
