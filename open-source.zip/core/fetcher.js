'use strict';
/**
 * 内容抓取：微信公众号 / GitHub / 通用网页 / 纯文本
 */
const { load } = require('cheerio');

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

function detectSourceType(url) {
  if (!url) return 'text';
  if (/mp\.weixin\.qq\.com/i.test(url)) return 'wechat';
  if (/github\.com|raw\.githubusercontent\.com|gist\.github\.com/i.test(url)) return 'github';
  if (/^https?:\/\//i.test(url)) return 'web';
  return 'text';
}

function normalizeUrl(url) {
  let u = String(url || '').trim();
  if (!u) return '';
  // 去掉微信复制时带的尾部参数噪音（保留必要查询）
  u = u.replace(/&amp;/g, '&');
  if (!/^https?:\/\//i.test(u) && /^(mp\.weixin\.qq\.com|github\.com)/i.test(u)) u = 'https://' + u;
  return u;
}

async function fetchHtml(url, headers = {}) {
  const resp = await fetch(url, {
    redirect: 'follow',
    headers: Object.assign(
      {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
      },
      headers
    ),
    signal: AbortSignal.timeout(25000)
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status} ${resp.statusText}`);
  const buf = Buffer.from(await resp.arrayBuffer());
  let charset = '';
  const ct = resp.headers.get('content-type') || '';
  const m1 = ct.match(/charset=([\w-]+)/i);
  if (m1) charset = m1[1];
  if (!charset) {
    const head = buf.slice(0, 4096).toString('latin1');
    const m2 = head.match(/charset=["']?([\w-]+)/i);
    if (m2) charset = m2[1];
  }
  charset = (charset || 'utf-8').toLowerCase();
  if (charset === 'gb2312' || charset === 'gbk') charset = 'gb18030';
  let html;
  try {
    html = new TextDecoder(charset).decode(buf);
  } catch (e) {
    html = new TextDecoder('utf-8').decode(buf);
  }
  return html;
}

/** 清洗 markdown / html 残留：注释、徽章、front matter、纯链接行、符号噪音 */
function cleanBody(text) {
  if (!text) return '';
  let t = String(text)
    .replace(/\r/g, '')
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/^\s*---\s*\n[\s\S]*?\n---\s*\n/, '')
    .replace(/\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)/g, '')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
    .replace(/\[+([^\[\]]+)\]+\([^)]*\)/g, '$1')
    .replace(/\*\*|__|~~|`/g, '')
    .replace(/<\/?[a-zA-Z][^>]*>/g, '');
  const lines = t.split('\n');
  const kept = [];
  for (const raw of lines) {
    const line = raw.replace(/\s+/g, ' ').trim();
    if (!line) {
      if (kept.length && kept[kept.length - 1] !== '') kept.push('');
      continue;
    }
    if (/^https?:\/\/[^\s]+$/i.test(line)) continue;
    if (/^[=\-_*#|~`>]{3,}$/.test(line)) continue;
    if (/[»›]|上一篇|下一篇/.test(line)) continue;
    if (/^[\d\s.,:;%+/-]+$/.test(line)) continue;
    // 去掉 markdown 前缀后再判断信息密度
    const stripped = line.replace(/^[#>*\-+\s]+/, '').replace(/[*_`]/g, '');
    const letters = (stripped.match(/[\u4e00-\u9fa5a-zA-Z]/g) || []).length;
    if (stripped.length > 0 && letters / stripped.length < 0.35) continue;
    if (letters < 3) continue;
    kept.push(stripped);
  }
  return kept.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

/* ---------------- 正文外链提取（官网 / GitHub / HuggingFace / 魔搭 等） ---------------- */

const LINK_KINDS = [
  { kind: 'github', site: 'GitHub', hosts: ['github.com', 'gist.github.com'] },
  { kind: 'huggingface', site: 'HuggingFace', hosts: ['huggingface.co'] },
  { kind: 'modelscope', site: '魔搭', hosts: ['modelscope.cn', 'modelscope.ai'] },
  { kind: 'gitee', site: 'Gitee', hosts: ['gitee.com'] },
  { kind: 'arxiv', site: 'arXiv', hosts: ['arxiv.org'] },
  { kind: 'paper', site: '论文', hosts: ['paperswithcode.com', 'openreview.net', 'aclanthology.org'] },
  { kind: 'video', site: '视频', hosts: ['youtube.com', 'bilibili.com', 'youtu.be'] }
];

const LINK_PRIORITY = ['github', 'huggingface', 'modelscope', 'gitee', 'arxiv', 'paper', 'doc', 'video', 'other'];

function classifyLink(url) {
  let host = '';
  try {
    host = new URL(url).hostname.replace(/^www\./i, '').toLowerCase();
  } catch (e) {
    return null;
  }
  for (const k of LINK_KINDS) {
    if (k.hosts.includes(host)) return { kind: k.kind, site: k.site, host };
  }
  if (/^(docs?|developer|readthedocs)\.[a-z0-9.-]+$/.test(host) || host === 'readthedocs.io') {
    return { kind: 'doc', site: '文档', host };
  }
  return { kind: 'other', site: host, host };
}

function normalizeLinkUrl(raw, baseUrl) {
  if (!raw) return '';
  let href = String(raw).trim().replace(/&amp;/g, '&');
  if (!href || /^(javascript:|mailto:|tel:|#)/i.test(href)) return '';
  if (/\.(png|jpg|jpeg|gif|svg|webp|ico|css|js|woff2?|ttf)(\?|$)/i.test(href)) return '';
  try {
    const u = new URL(href, baseUrl || 'https://example.com');
    if (!/^https?:$/.test(u.protocol)) return '';
    u.hash = '';
    ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'from', 'spm'].forEach((k) =>
      u.searchParams.delete(k)
    );
    return u.toString().replace(/\/$/, '');
  } catch (e) {
    return '';
  }
}

function pickLabel(text, url) {
  let t = String(text || '')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
    .replace(/\[+([^\[\]]+)\]+\([^)]*\)/g, '$1')
    .replace(/[*_`#>]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!t) {
    try {
      const u = new URL(url);
      t = decodeURIComponent((u.pathname.split('/').filter(Boolean).pop() || u.hostname).slice(0, 40));
    } catch (e) {
      t = url;
    }
  }
  return t.length > 42 ? t.slice(0, 42) + '…' : t;
}

/** 判断链接是否只是「同一个项目」的内部导航（如 README 里的 LICENSE、issues、源码文件） */
function isSameProject(url, sourceUrl) {
  if (!sourceUrl) return false;
  try {
    const a = new URL(url);
    const b = new URL(sourceUrl);
    const ah = a.hostname.replace(/^www\./i, '').toLowerCase();
    const bh = b.hostname.replace(/^www\./i, '').toLowerCase();
    if (ah !== bh) return false;
    if (!/(github\.com|gitee\.com|huggingface\.co|modelscope\.(cn|ai))/.test(ah)) return false;
    const segs = b.pathname.split('/').filter(Boolean).map((s) => s.toLowerCase());
    if (segs.length < 2) return false;
    const prefix = '/' + segs.slice(0, 2).join('/');
    return a.pathname.toLowerCase().replace(/\.git$/, '').startsWith(prefix);
  } catch (e) {
    return false;
  }
}

/** 统一去重 + 按类型优先级排序 + 截断 */
function finalizeLinks(list, { skipHosts = [], limit = 12, sourceUrl = '' } = {}) {
  const seen = new Set();
  const out = [];
  (list || []).forEach((l) => {
    if (!l || !l.url) return;
    if (seen.has(l.url)) return;
    const cls = classifyLink(l.url);
    if (!cls) return;
    if (skipHosts.includes(cls.host)) return;
    if (isSameProject(l.url, sourceUrl)) return;
    // 导航类噪音：仓库的 issue / release / .git / 纯哈希
    if (/\.git$/.test(l.url)) return;
    if (/^[0-9a-f]{7,40}$/i.test(String(l.label || '')) || /^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(l.label || '')) return;
    seen.add(l.url);
    out.push({
      url: l.url,
      label: l.label || pickLabel('', l.url),
      kind: cls.kind,
      site: cls.site,
      host: cls.host
    });
  });
  out.sort((a, b) => LINK_PRIORITY.indexOf(a.kind) - LINK_PRIORITY.indexOf(b.kind));
  return out.slice(0, limit);
}

/** 收集 HTML 里的原始链接（不排序、不截断）：href / data-link / 链接文本本身是网址 */
function collectHtmlLinks($, node, baseUrl) {
  const list = [];
  if (!node || !node.length) return list;
  $(node)
    .find('a')
    .each((i, el) => {
      const $a = $(el);
      // 公众号常把外链挂在 data-link / data-url / data-href 上，href 只剩 javascript:void(0)
      const candidates = [$a.attr('href'), $a.attr('data-link'), $a.attr('data-url'), $a.attr('data-href')];
      const textUrl = ($a.text() || '').trim();
      if (/^(https?:\/\/|www\.)/i.test(textUrl)) candidates.push(textUrl);
      for (const c of candidates) {
        const url = normalizeLinkUrl(c, baseUrl);
        if (!url) continue;
        list.push({ url, label: pickLabel($a.text(), url) });
        break;
      }
    });
  return list;
}

/** 从正文纯文本里捞链接：带协议的网址 + 有上下文关键词的无协议域名 */
const TEXT_LINK_KEYWORDS =
  /(官网|网址|地址|主页|首页|链接|文档|仓库|项目|源码|下载|安装|镜像|博客|社区|代码|论文|视频|Website|Homepage|Docs|GitHub|Demo|Link)/i;
const BARE_DOMAIN_RE =
  /(?:https?:\/\/)?((?:[a-z0-9][a-z0-9-]*\.)+(?:com|cn|org|net|io|ai|dev|co|me|app|xyz|cc|tv|tech|site|wiki|edu|gov)(?::\d+)?(?:\/[^\s，。；、）)\]】"'<>]*)?)/gi;

function collectTextLinks(text, baseUrl) {
  const list = [];
  const raw = String(text || '');
  // 1) 明确带 http(s) 的网址
  const withScheme = /https?:\/\/[^\s<>"'`，。；、）)\]】]+/gi;
  let m;
  while ((m = withScheme.exec(raw))) {
    const url = normalizeLinkUrl(m[0].replace(/[.,;:!?]+$/, ''), baseUrl);
    if (url) list.push({ url, label: pickLabel('', url) });
  }
  // 2) 无协议域名（必须是常见顶级域名，且前面 20 字内有关键词，避免把 README.md 之类误当链接）
  let d;
  BARE_DOMAIN_RE.lastIndex = 0;
  while ((d = BARE_DOMAIN_RE.exec(raw))) {
    const token = d[1];
    if (/^https?:\/\//i.test(d[0])) continue; // 已在第 1 步收过
    const known =
      /^(www\.|github\.com|gitee\.com|huggingface\.co|modelscope\.(cn|ai)|arxiv\.org|pytorch\.org)/i.test(token);
    const before = raw.slice(Math.max(0, d.index - 40), d.index);
    if (!known && !TEXT_LINK_KEYWORDS.test(before)) continue;
    const url = normalizeLinkUrl(/^https?:\/\//i.test(token) ? token : 'https://' + token, baseUrl);
    if (url) list.push({ url, label: pickLabel('', url) });
  }
  return list;
}

function extractLinksFromHtml($, node, baseUrl, sourceUrl) {
  return finalizeLinks(collectHtmlLinks($, node, baseUrl), {
    skipHosts: ['mp.weixin.qq.com'],
    sourceUrl: sourceUrl || baseUrl
  });
}

function extractLinksFromMarkdown(md, baseUrl, sourceUrl) {
  const list = [];
  const text = String(md || '');
  const mdLink = /\[([^\]]{0,140})\]\((https?:\/\/[^\s)]+)\)/g;
  let m;
  while ((m = mdLink.exec(text))) {
    const url = normalizeLinkUrl(m[2], baseUrl);
    if (url) list.push({ url, label: pickLabel(m[1], url) });
  }
  const bare = /https?:\/\/[^\s<>"'`)\]]+/g;
  let b;
  while ((b = bare.exec(text))) {
    const url = normalizeLinkUrl(b[0], baseUrl);
    if (url) list.push({ url, label: pickLabel('', url) });
  }
  return finalizeLinks(list, { sourceUrl: sourceUrl || '' });
}

function extractLinksFromText(text, baseUrl, sourceUrl) {
  return extractLinksFromMarkdown(text, baseUrl, sourceUrl);
}

function withTimeout(promise, ms, label) {
  let timer = null;
  const timeout = new Promise((resolve, reject) => {
    timer = setTimeout(
      () => reject(new Error((label || '请求') + '超时（' + Math.round(ms / 1000) + ' 秒）')),
      ms
    );
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

async function ghFetch(pathname, token, accept) {
  const headers = {
    'User-Agent': UA,
    Accept: accept || 'application/vnd.github+json'
  };
  if (token) headers.Authorization = `token ${token}`;
  return fetch('https://api.github.com' + pathname, {
    headers,
    signal: AbortSignal.timeout(15000)
  });
}

/** 把 HTML 片段转成干净纯文本，尽量保留段落 */
function extractText($, node, { keepLinks = false } = {}) {
  if (!node) return '';
  const $c = $(node).clone();
  $c.find('script,style,noscript,iframe,svg,form,video,audio').remove();
  $c.find('br').replaceWith('\n');
  $c.find('p,section,h1,h2,h3,h4,h5,h6,li,tr,blockquote,pre,div').each((i, el) => {
    $(el).append('\n');
  });
  let text = $c.text() || '';
  text = text
    .replace(/\u00a0/g, ' ')
    .replace(/\r/g, '')
    .replace(/[ \t]+/g, ' ')
    .replace(/ *\n */g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  return text;
}

function pickBestContainer($) {
  const candidates = [
    'article',
    '#js_content',
    '.rich_media_content',
    'main article',
    'main',
    '.post-content',
    '.article-content',
    '.entry-content',
    '#content',
    '.content',
    'body'
  ];
  let best = null;
  let bestLen = 0;
  for (const sel of candidates) {
    const el = $(sel).first();
    if (!el || el.length === 0) continue;
    const txt = el.text() || '';
    if (txt.length > bestLen) {
      bestLen = txt.length;
      best = el;
    }
  }
  return best;
}

function metaContent($, names) {
  for (const n of names) {
    const v = $(`meta[property="${n}"], meta[name="${n}"]`).attr('content');
    if (v && v.trim()) return v.trim();
  }
  return '';
}

function cleanTitle(s) {
  return String(s || '')
    .replace(/\s+/g, ' ')
    .replace(/^[-|·]\s*/, '')
    .trim();
}

/** 解析公众号文章 HTML（独立出来，便于离线单测） */
function parseWechatHtml(html, baseUrl) {
  const $ = load(html);
  const title =
    cleanTitle($('#activity-name').text()) ||
    cleanTitle(metaContent($, ['og:title', 'twitter:title'])) ||
    cleanTitle($('title').text());
  const coverUrl = metaContent($, ['og:image', 'twitter:image']);

  let content = '';
  const jsContent = $('#js_content');
  if (jsContent.length) content = extractText($, jsContent);

  if (content.length < 80) {
    const rich = $('.rich_media_content');
    if (rich.length) content = extractText($, rich);
  }
  if (content.length < 80) {
    const body = extractText($, pickBestContainer($));
    if (body.length > content.length) content = body;
  }
  if (content.length < 40) {
    const desc = metaContent($, ['og:description', 'description']);
    if (desc) content = desc;
  }
  // 外链：正文 a[href]/data-link + 正文里以纯文本写出的网址 + 文末「阅读原文」
  const container = jsContent.length ? jsContent : pickBestContainer($);
  const rawLinks = [];
  rawLinks.push(...collectHtmlLinks($, container, baseUrl));
  rawLinks.push(...collectTextLinks(content, baseUrl));
  rawLinks.push(...collectHtmlLinks($, $('#js_article, .rich_media_area_extra, .original_area_primary, #js_original_link'), baseUrl));
  const links = finalizeLinks(rawLinks, { skipHosts: ['mp.weixin.qq.com'], sourceUrl: baseUrl });
  return {
    title: title || '(公众号文章)',
    text: cleanBody(content),
    coverUrl,
    sourceType: 'wechat',
    links
  };
}

async function fetchWechat(url) {
  const html = await fetchHtml(url, { Referer: 'https://mp.weixin.qq.com/' });
  const r = parseWechatHtml(html, url);
  if (!r.text || r.text.length < 20) {
    throw new Error('未能从该公众号页面提取到正文（可能需要登录/校验，或链接已失效）');
  }
  return r;
}

/**
 * GitHub 一律走 API（github.com 网页域名在部分网络下不可直达，api.github.com 更稳）
 */
async function fetchGithubRepo(owner, repo, token) {
  const resp = await ghFetch(`/repos/${owner}/${repo}/readme`, token, 'application/vnd.github.raw+json');
  if (resp.ok) {
    const txt = await resp.text();
    if (txt && txt.trim().length > 30) {
      return {
        title: `${owner}/${repo}`,
        text: cleanBody(txt),
        coverUrl: '',
        sourceType: 'github',
        links: extractLinksFromMarkdown(txt, '', `https://github.com/${owner}/${repo}`)
      };
    }
  }
  if (!resp.ok) {
    // API 不可用（限流/私有仓库）时回退到 raw.githubusercontent.com，实测该域名更稳
    for (const branch of ['main', 'master']) {
      for (const name of ['README.md', 'readme.md', 'Readme.md']) {
        try {
          const txt = await fetchHtml(
            `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${name}`,
            { Accept: 'text/plain' }
          );
          if (txt && txt.trim().length > 30) {
            return {
              title: `${owner}/${repo}`,
              text: cleanBody(txt),
              coverUrl: '',
              sourceType: 'github',
              links: extractLinksFromMarkdown(txt, '', `https://github.com/${owner}/${repo}`)
            };
          }
        } catch (e) {
          /* 继续尝试下一个分支/文件名 */
        }
      }
    }
  }
  const info = await ghFetch(`/repos/${owner}/${repo}`, token);
  if (info.ok) {
    const j = await info.json();
    const text = [
      j.full_name || `${owner}/${repo}`,
      j.description || '',
      j.language ? '主要语言：' + j.language : '',
      typeof j.stargazers_count === 'number' ? `Star：${j.stargazers_count}` : '',
      j.topics && j.topics.length ? 'Topics：' + j.topics.join(', ') : ''
    ]
      .filter(Boolean)
      .join('\n');
    return { title: j.full_name || `${owner}/${repo}`, text, coverUrl: '', sourceType: 'github' };
  }
  throw new Error('无法读取该 GitHub 仓库（私有仓库请在设置里填写 GitHub Token，或检查仓库地址）');
}

async function fetchGithub(url, token) {
  // 1) raw 文件
  const rawMatch = url.match(/^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/i);
  if (rawMatch) {
    const text = await fetchHtml(url, { Accept: 'text/plain' });
    return {
      title: rawMatch[4].split('/').pop(),
      text: cleanBody(text),
      coverUrl: '',
      sourceType: 'github',
      links: extractLinksFromMarkdown(text, url, url)
    };
  }

  // 2) blob 单文件 → 转 raw
  const blobMatch = url.match(/^https:\/\/github\.com\/([^/]+)\/([^/]+)\/blob\/([^/]+)\/([^?#]+)/i);
  if (blobMatch) {
    const [, owner, repo, branch, p] = blobMatch;
    const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${p}`;
    const text = await fetchHtml(rawUrl, { Accept: 'text/plain' });
    return {
      title: p.split('/').pop(),
      text: cleanBody(text),
      coverUrl: '',
      sourceType: 'github',
      links: extractLinksFromMarkdown(text, url, url)
    };
  }

  // 3) gist
  const gistMatch = url.match(/^https:\/\/gist\.github\.com\/([^/]+)\/([a-f0-9]+)/i);
  if (gistMatch) {
    const resp = await ghFetch(`/gists/${gistMatch[2]}`, token);
    if (!resp.ok) throw new Error('无法读取该 Gist（' + resp.status + '）');
    const j = await resp.json();
    const files = j.files || {};
    const text = Object.keys(files)
      .map((name) => `// ${name}\n${(files[name] && files[name].content) || ''}`)
      .join('\n\n');
    return {
      title: j.description || Object.keys(files)[0] || 'Gist',
      text: cleanBody(text),
      coverUrl: '',
      sourceType: 'github',
      links: extractLinksFromMarkdown(text, url, url)
    };
  }

  // 4) issue / pull request
  const issueMatch = url.match(/^https:\/\/github\.com\/([^/]+)\/([^/]+)\/(?:issues|pull)\/(\d+)/i);
  if (issueMatch) {
    const [, owner, repo, num] = issueMatch;
    const resp = await ghFetch(`/repos/${owner}/${repo}/issues/${num}`, token);
    if (!resp.ok) throw new Error('无法读取该 Issue（' + resp.status + '）');
    const j = await resp.json();
    const text = [
      `#${j.number} ${j.title || ''}`,
      j.state ? `状态：${j.state}` : '',
      (j.user && j.user.login) || '',
      j.body || ''
    ]
      .filter(Boolean)
      .join('\n');
    return {
      title: `#${j.number} ${j.title || 'Issue'}`,
      text: cleanBody(text),
      coverUrl: '',
      sourceType: 'github',
      links: extractLinksFromMarkdown(j.body || '', url, url)
    };
  }

  // 5) 仓库 / tree / 其它
  const repoMatch = url.match(/^https:\/\/github\.com\/([^/]+)\/([^/#?]+)(?:[/?#].*)?$/i);
  if (repoMatch) {
    const [, owner, repo] = repoMatch;
    try {
      return await fetchGithubRepo(owner, repo.replace(/\.git$/i, ''), token);
    } catch (e) {
      // 落到 HTML 兜底之前，保留原错误便于排查
      if (!/仓库/.test(e.message)) throw e;
      throw e;
    }
  }

  // 6) 兜底：HTML 解析（带硬超时，避免域名不可达时长时间挂起）
  const html = await withTimeout(fetchHtml(url), 15000, 'GitHub 页面抓取');
  const $ = load(html);
  const title = cleanTitle(metaContent($, ['og:title'])) || cleanTitle($('title').text()) || 'GitHub';

  const selectors = [
    'article.markdown-body',
    '.markdown-body',
    '[data-testid="issue-body"]',
    '.comment-body',
    'article'
  ];
  let text = '';
  for (const sel of selectors) {
    const el = $(sel).first();
    if (el.length) {
      const t = extractText($, el);
      if (t.length > text.length) text = t;
    }
  }
  if (text.length < 80) text = extractText($, pickBestContainer($));
  if (text.length < 40) {
    const desc = metaContent($, ['og:description', 'description']);
    if (desc) text = desc;
  }
  if (text.length < 20) throw new Error('未能提取到 GitHub 页面正文，请改用仓库首页 / 单文件 / Issue 链接');
  return { title, text, coverUrl: '', sourceType: 'github' };
}

async function fetchWeb(url) {
  const html = await fetchHtml(url);
  const $ = load(html);
  $('nav,footer,aside,header,script,style,noscript,iframe,svg').remove();
  const title =
    cleanTitle(metaContent($, ['og:title', 'twitter:title'])) ||
    cleanTitle($('h1').first().text()) ||
    cleanTitle($('title').text()) ||
    '网页内容';
  const coverUrl = metaContent($, ['og:image', 'twitter:image']);
  const container = pickBestContainer($);
  let text = extractText($, container);
  if (text.length < 200) {
    const desc = metaContent($, ['og:description', 'description']);
    text = text + (desc ? '\n' + desc : '');
  }
  if (text.length < 20) throw new Error('未能提取到网页正文（可能是动态渲染页面或需要登录）');
  // 网页同样补一层「正文里以纯文本写出的网址」，很多博客/新闻把链接直接写成文字
  const rawLinks = collectHtmlLinks($, container, url);
  rawLinks.push(...collectTextLinks(text, url));
  const links = finalizeLinks(rawLinks, { sourceUrl: '' });
  return { title, text: cleanBody(text), coverUrl, sourceType: 'web', links };
}

/**
 * 主入口
 * @returns {{title:string, text:string, coverUrl:string, sourceType:string, finalUrl:string}}
 */
async function fetchSource({ url, rawText, githubToken }) {
  if (rawText && rawText.trim().length > 0 && !url) {
    const text = rawText.replace(/\r/g, '').replace(/\n{3,}/g, '\n\n').trim();
    return {
      title: firstLineTitle(text),
      text,
      coverUrl: '',
      sourceType: 'text',
      finalUrl: '',
      links: extractLinksFromText(text)
    };
  }
  if (!url) throw new Error('请提供链接或文本内容');
  url = normalizeUrl(url);
  const type = detectSourceType(url);
  if (type === 'wechat') {
    const r = await withTimeout(fetchWechat(url), 30000, '公众号抓取');
    return Object.assign(r, { finalUrl: url });
  }
  if (type === 'github') {
    const r = await withTimeout(fetchGithub(url, githubToken), 30000, 'GitHub 抓取');
    return Object.assign(r, { finalUrl: url });
  }
  const r = await withTimeout(fetchWeb(url), 30000, '网页抓取');
  return Object.assign(r, { finalUrl: url });
}

function firstLineTitle(text) {
  const lines = text.split('\n').map((s) => s.trim()).filter(Boolean);
  const first = lines[0] || '文本片段';
  return first.length > 40 ? first.slice(0, 40) + '…' : first;
}

module.exports = {
  fetchSource,
  detectSourceType,
  normalizeUrl,
  fetchHtml,
  extractText,
  cleanBody,
  parseWechatHtml,
  extractLinksFromMarkdown,
  extractLinksFromText,
  extractLinksFromHtml,
  collectHtmlLinks,
  collectTextLinks,
  finalizeLinks,
  classifyLink
};
