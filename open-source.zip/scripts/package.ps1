﻿# 打包为免安装 Windows 目录（不依赖 electron-builder，可整目录拷走）
# 用法：powershell -ExecutionPolicy Bypass -File scripts\package.ps1
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot            # 应用源码目录
$parent = Split-Path -Parent $root                  # 项目目录
$out = Join-Path $parent '随手贴-Windows'

if (Test-Path -LiteralPath $out) {
  throw "输出目录已存在：$out。请先改名或删除，本脚本不会覆盖已有产物。"
}

$dist = Join-Path $root 'node_modules\electron\dist'
$exe = Join-Path $dist 'electron.exe'
if (-not (Test-Path -LiteralPath $exe)) {
  throw ('未找到 Electron 运行时：' + $exe + '。请先在 ' + $root + ' 执行 npm install，或执行 node node_modules/electron/install.js。')
}

Write-Host "1/6 创建输出目录"
New-Item -ItemType Directory -Path $out -Force | Out-Null

Write-Host "2/6 复制 Electron 运行时"
Copy-Item -Path (Join-Path $dist '*') -Destination $out -Recurse -Force

Write-Host "3/6 复制应用代码"
$appDir = Join-Path $out 'resources\app'
New-Item -ItemType Directory -Path $appDir -Force | Out-Null
foreach ($f in @('main.js', 'preload.js', 'package.json')) {
  Copy-Item -Path (Join-Path $root $f) -Destination $appDir -Force
}
foreach ($d in @('core', 'renderer', 'scripts')) {
  Copy-Item -Path (Join-Path $root $d) -Destination $appDir -Recurse -Force
}

Write-Host "4/6 复制运行时依赖（排除 electron 与类型包）"
$nmTarget = Join-Path $appDir 'node_modules'
New-Item -ItemType Directory -Path $nmTarget -Force | Out-Null
$exclude = @('electron', '@electron', '@electron-internal', '@types', '.bin', '.package-lock.json')
Get-ChildItem -LiteralPath (Join-Path $root 'node_modules') -Force |
  Where-Object { $exclude -notcontains $_.Name } |
  ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $nmTarget $_.Name) -Recurse -Force }

Write-Host "5/6 清理默认入口并重命名主程序"
$defaultApp = Join-Path $out 'resources\default_app.asar'
if (Test-Path -LiteralPath $defaultApp) { Remove-Item -LiteralPath $defaultApp -Force }
Rename-Item -LiteralPath (Join-Path $out 'electron.exe') -NewName '随手贴.exe'

Write-Host "6/6 写入使用说明"
$readme = @"
随手贴 · 本地知识库（Windows 免安装版）
=====================================

启动：双击「随手贴.exe」，无需安装 Node，无需启动任何后端服务。

第一次使用建议：
  1. 右上角齿轮 → 设置：可选填大模型接口（不填则用内置本地摘要，离线可用）。
  2. 主界面「＋ 新增知识」：粘贴公众号 / GitHub / 网页链接，或直接粘贴一段文字。
  3. 生成摘要后确认分类与标签，保存入库；需要跟踪原文变化就勾选「开启持续追踪」。
  4. 详情页可写笔记、看历史版本、导出 Markdown。
  5. 正文里的官网 / GitHub / HuggingFace / 魔搭链接会自动抽取，详情页「相关链接」可点击直达；
     老条目可在详情页点「只补外链」或「重新抓取」（后者会重抓正文、重算摘要、重抽链接，旧摘要进版本记录）。
  6. 列表右上角切「知识树」：按分类聚合并自动生成归类总结，点条目直接进详情。
     切「思维导图」：以「随手贴 → 分类 → 知识」的节点连线展示整库结构，点条目进详情、点分类回到该分类列表；
     导图默认「适应宽度」，可用右上角 －/＋ 缩放，内容超出时右侧滚动条可上下拖拽查看。
  7. 删除：卡片右上角「✕」或详情页底部「删除」，都会先弹确认框。
  8. 防重复：同一来源再存一次会提示「更新已有条目」；列表会标「疑似重复」，列表头出现「清理重复（N）」。
  9. 导入 Word / Excel：新增弹窗切到「导入文档」→ 选 .docx / .xlsx，自动读出正文与文中链接并生成摘要；
     保存时可勾选「把链接内容也抓成独立知识」（最多 4 条）。旧版 .doc / .xls 需先另存为新格式。

数据位置：
  %APPDATA%\随手贴\data\data.json
  设置页「打开数据目录」可直接定位；卸载程序不会删除该目录，重装可继续用。
  备份：设置页「导出 JSON 备份」。

支持的链接：
  · 微信公众号文章  mp.weixin.qq.com/s/...
  · GitHub 仓库 / 单文件 / Issue / Gist
  · 任意普通网页
  · 纯文本（无链接）
  · 导入文件：Word（.docx）、Excel（.xlsx）

注意：
  · 公众号必须是可公开访问的文章链接，遇到「环境异常/需要验证」的页面会抓取失败。
  · GitHub 私有仓库需要在设置里填写 Token。
  · 所有数据只存本机，不会上传到任何服务器；启用大模型时仅正文会发送到你配置的接口。
"@
[IO.File]::WriteAllText((Join-Path $out '使用说明.txt'), ($readme -replace "`n", "`r`n"), (New-Object Text.UTF8Encoding $true))

$size = (Get-ChildItem -LiteralPath $out -Recurse -File | Measure-Object -Property Length -Sum).Sum / 1MB
Write-Host ("完成：{0}  约 {1:N0} MB" -f $out, $size)
Write-Host ("主程序：{0}" -f (Join-Path $out '随手贴.exe'))
