'use strict';
/**
 * 内置自检：既验证核心逻辑（Node 侧），也验证真实渲染界面（offscreen 窗口）。
 * 结果写入 txt，供外部读取判断，不依赖终端 stdout。
 */
const path = require('path');
const fs = require('fs');
const os = require('os');
const zlib = require('zlib');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function runSelfTest({ app, BrowserWindow, store, outPath, rootDir }) {
  const lines = [];
  let failed = 0;

  const check = (name, cond, detail = '') => {
    if (cond) {
      lines.push(`[PASS] ${name}`);
    } else {
      failed++;
      lines.push(`[FAIL] ${name}${detail ? ' — ' + detail : ''}`);
    }
  };

  const guard = setTimeout(() => {
    lines.push('[FAIL] 自检超时（120s）');
    finish();
  }, 120000);

  function finish() {
    try {
      fs.mkdirSync(path.dirname(outPath), { recursive: true });
      lines.push('');
      lines.push(`结果：${failed === 0 ? 'ALL PASS' : failed + ' 项失败'}`);
      lines.push(`时间：${new Date().toISOString()}`);
      lines.push(`数据目录：${store ? store.file : '(none)'}`);
      fs.writeFileSync(outPath, lines.join('\r\n'), 'utf8');
    } catch (e) {
      try {
        fs.appendFileSync(
          path.join(__dirname, '..', 'output', 'selftest-write-error.log'),
          new Date().toISOString() + ' out=' + outPath + ' err=' + (e && e.message) + '\n'
        );
      } catch (e2) {
        /* ignore */
      }
    }
    setTimeout(() => app.exit(failed === 0 ? 0 : 1), 300);
  }

  try {
    /* ------------------ 1. 纯逻辑 ------------------ */
    const fetcher = require('../core/fetcher');
    const summarizer = require('../core/summarize');
    const exporter = require('../core/exporter');
    const { Tracker, hashText } = require('../core/tracker');

    check('来源类型识别：公众号', fetcher.detectSourceType('https://mp.weixin.qq.com/s/abcdef') === 'wechat');
    check('来源类型识别：GitHub', fetcher.detectSourceType('https://github.com/openai/gpt-4o') === 'github');
    check('来源类型识别：普通网页', fetcher.detectSourceType('https://example.com/post/1') === 'web');

    const wxHtml = `<!DOCTYPE html><html><head>
      <meta property="og:title" content="测试公众号文章标题" />
      <meta property="og:image" content="https://mmbiz.qpic.cn/demo.jpg" />
      </head><body>
      <h1 id="activity-name"> 测试公众号文章标题 </h1>
      <div id="js_content">
        <p>这是第一段正文，用于验证公众号正文提取逻辑是否可靠。</p>
        <p>第二段内容包含一些技术细节、关键结论以及后续计划。</p>
        <p>开源地址：<a href="https://github.com/demo/repo">GitHub 源码</a>，模型在 <a href="https://huggingface.co/demo/model">HuggingFace</a> 与 <a href="https://modelscope.cn/models/demo/m">魔搭社区</a>。</p>
        <p>项目官网 <a href="javascript:void(0)" data-link="https://demo-official.example.com/docs">点这里</a>，文档见 https://demo-official.example.com/guide 。</p>
        <p>国内镜像可以看到 modelscope.cn/models/demo/other ，也可以访问 www.demo-blog.cn/post。</p>
        <p>下载地址：https://gitee.com/demo/repo/releases</p>
        <script>var x = 1;</script>
      </div>
      <div class="rich_media_area_extra">
        <a href="https://example.com/original-article">阅读原文</a>
      </div>
      </body></html>`;
    const wx = fetcher.parseWechatHtml(wxHtml, 'https://mp.weixin.qq.com/s/demo');
    check('公众号解析：标题正确', wx.title === '测试公众号文章标题', 'title=' + wx.title);
    check('公众号解析：正文包含段落', wx.text.includes('第一段正文') && wx.text.includes('第二段内容'));
    check('公众号解析：剔除脚本与标签', !wx.text.includes('var x') && !wx.text.includes('<p>'));
    check('公众号解析：封面图', wx.coverUrl.includes('mmbiz.qpic.cn'));
    check('公众号解析：提取正文外链', Array.isArray(wx.links) && wx.links.length >= 2, 'links=' + JSON.stringify(wx.links));
    check(
      '公众号解析：识别 GitHub / HuggingFace / 魔搭',
      ['github', 'huggingface', 'modelscope'].every((k) => (wx.links || []).some((l) => l.kind === k)),
      'kinds=' + JSON.stringify((wx.links || []).map((l) => l.kind))
    );
    check(
      '公众号解析：抓 data-link 隐藏外链',
      (wx.links || []).some((l) => l.url.includes('demo-official.example.com/docs')),
      JSON.stringify((wx.links || []).map((l) => l.url))
    );
    check(
      '公众号解析：抓正文纯文本网址',
      (wx.links || []).some((l) => l.url.includes('demo-official.example.com/guide')) &&
        (wx.links || []).some((l) => l.url.includes('www.demo-blog.cn/post')),
      JSON.stringify((wx.links || []).map((l) => l.url))
    );
    check(
      '公众号解析：抓无协议域名',
      (wx.links || []).some((l) => l.url.includes('modelscope.cn/models/demo/other')),
      JSON.stringify((wx.links || []).map((l) => l.url))
    );
    check(
      '公众号解析：抓文末阅读原文',
      (wx.links || []).some((l) => l.url.includes('example.com/original-article')),
      JSON.stringify((wx.links || []).map((l) => l.url))
    );

    const sample =
      '大模型推理成本正在快速下降。过去一年，主流厂商的推理单价下降了约七成，' +
      '这主要来自三方面：更高效的注意力实现、更激进的量化策略，以及批处理调度的优化。' +
      '对于应用开发者来说，成本下降意味着可以把更大的模型放到线上链路里。' +
      '不过延迟仍然是瓶颈，尤其在多轮对话场景下，首 token 延迟直接决定体验。' +
      '因此在工程实践中，常见做法是小模型做路由，大模型只处理复杂请求。' +
      '这套组合在真实业务中能把平均成本压到原来的三分之一，同时保持回答质量。';

    const local = summarizer.summarizeLocal({ title: '大模型推理成本观察', text: sample });
    check('本地摘要：摘要非空且不过长', local.summary.length > 40 && local.summary.length <= 400, 'len=' + local.summary.length);
    check('本地摘要：保留具体数字', /三|七成|三分之/.test(local.summary), 'summary=' + local.summary.slice(0, 80));
    check('本地摘要：生成要点', Array.isArray(local.keyPoints) && local.keyPoints.length >= 2, 'points=' + local.keyPoints.length);
    check('本地摘要：生成标签', Array.isArray(local.tags) && local.tags.length >= 1, 'tags=' + JSON.stringify(local.tags));
    check('本地摘要：分类命中 AI', local.category === 'AI与大模型' || local.category === '其他', 'cat=' + local.category);

    check('追踪哈希：同文本同哈希', hashText('abc') === hashText('abc'));
    check('追踪哈希：不同文本不同哈希', hashText('abc') !== hashText('abc '));

    const mdLinks = fetcher.extractLinksFromMarkdown(
      '项目主页 https://github.com/openai/whisper ，模型 https://huggingface.co/openai/whisper-large-v3 ，' +
        '国内镜像 https://modelscope.cn/models/qwen/Qwen2.5-7B ，官网 https://openai.com/index/whisper ，' +
        '[文档](https://docs.python.org/3/) 以及重复链接 https://github.com/openai/whisper 。'
    );
    check('外链提取：识别 GitHub', mdLinks.some((l) => l.kind === 'github'), 'n=' + mdLinks.length);
    check('外链提取：识别 HuggingFace', mdLinks.some((l) => l.kind === 'huggingface'));
    check('外链提取：识别魔搭', mdLinks.some((l) => l.kind === 'modelscope'));
    check('外链提取：去重', new Set(mdLinks.map((l) => l.url)).size === mdLinks.length, 'links=' + JSON.stringify(mdLinks.map((l) => l.url)));
    check('外链提取：按类型优先级排序', mdLinks[0].kind === 'github', 'first=' + mdLinks[0].kind);
    check('外链提取：上限 12 条', mdLinks.length <= 12);

    /* ------------------ 2. 仓库读写 ------------------ */
    store.clearAll();
    const cats = store.getCategories();
    const base = {
      summary: '用于自检的摘要内容，说明这条知识已经被正确结构化保存。',
      keyPoints: ['要点一', '要点二'],
      categoryId: cats[0] ? cats[0].id : 0,
      tags: ['自检', 'AI'],
      contentHash: hashText('sample body'),
      charCount: 120
    };
    const itemA = store.addItem(
      Object.assign({}, base, {
        title: '测试条目A · 公众号长文',
        sourceUrl: 'https://mp.weixin.qq.com/s/abcdefg',
        sourceType: 'wechat',
        enableTrack: true,
        trackIntervalHours: 24,
        links: [
          { url: 'https://github.com/demo/repo', label: 'GitHub 源码', kind: 'github', site: 'GitHub' },
          { url: 'https://huggingface.co/demo/model', label: 'HuggingFace 模型', kind: 'huggingface', site: 'HuggingFace' }
        ]
      })
    );
    const itemB = store.addItem(
      Object.assign({}, base, {
        title: '测试条目B · 纯文本笔记',
        sourceUrl: '',
        sourceType: 'text',
        summary: '纯文本录入的摘要，用于验证搜索过滤。'
      })
    );
    check('条目写入：返回 id', typeof itemA.id === 'number' && itemA.id > 0);
    check('条目写入：条目数正确', store.getItems().length === 2, 'n=' + store.getItems().length);

    store.updateItem(itemA.id, { note: '这是自检写入的笔记内容。' });
    check('条目更新：笔记落库', store.getItem(itemA.id).note.includes('自检写入'));

    const md = exporter.buildMarkdown(store.getItems(), cats);
    check('Markdown 导出：含标题', md.includes('测试条目A'));
    check('Markdown 导出：含来源链接', md.includes('mp.weixin.qq.com'));
    check('Markdown 导出：含笔记', md.includes('自检写入的笔记'));
    check('Markdown 导出：含要点', md.includes('要点一'));

    const backup = store.exportAll();
    check('JSON 备份：包含条目', Array.isArray(backup.items) && backup.items.length === 2);
    check('JSON 备份：包含分类', Array.isArray(backup.categories) && backup.categories.length > 0);
    check('条目写入：外链落库', (store.getItem(itemA.id).links || []).length === 2);

    const catSum = summarizer.aggregateLocal({ categoryName: cats[0] ? cats[0].name : 'AI与大模型', items: store.getItems() });
    check('归类总结：本地归纳非空', catSum.summary.length > 30, 'summary=' + catSum.summary.slice(0, 60));
    check('归类总结：包含条目数', catSum.summary.includes('2 条'), 'summary=' + catSum.summary.slice(0, 60));

    /* ---------------- Word / Excel 导入 ---------------- */
    const office = require('../core/office');

    const crcTable = (() => {
      const t = [];
      for (let n = 0; n < 256; n++) {
        let c = n;
        for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
        t[n] = c >>> 0;
      }
      return t;
    })();
    const crc32 = (buf) => {
      let c = 0xffffffff;
      for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8);
      return (c ^ 0xffffffff) >>> 0;
    };
    // 最小 zip 写入器；deflate=true 时用真实 Office 同一套压缩算法，验证读取端的 inflate 路径
    const makeZip = (files, deflate) => {
      const parts = [];
      const central = [];
      let offset = 0;
      const names = Object.keys(files);
      names.forEach((name) => {
        const nameBuf = Buffer.from(name, 'utf8');
        const raw = Buffer.from(files[name], 'utf8');
        const data = deflate ? zlib.deflateRawSync(raw) : raw;
        const crc = crc32(raw);
        const method = deflate ? 8 : 0;
        const local = Buffer.alloc(30);
        local.writeUInt32LE(0x04034b50, 0);
        local.writeUInt16LE(20, 4);
        local.writeUInt16LE(method, 8);
        local.writeUInt32LE(crc, 14);
        local.writeUInt32LE(data.length, 18);
        local.writeUInt32LE(raw.length, 22);
        local.writeUInt16LE(nameBuf.length, 26);
        parts.push(local, nameBuf, data);
        const cen = Buffer.alloc(46);
        cen.writeUInt32LE(0x02014b50, 0);
        cen.writeUInt16LE(20, 4);
        cen.writeUInt16LE(20, 6);
        cen.writeUInt16LE(method, 10);
        cen.writeUInt32LE(crc, 16);
        cen.writeUInt32LE(data.length, 20);
        cen.writeUInt32LE(raw.length, 24);
        cen.writeUInt16LE(nameBuf.length, 28);
        cen.writeUInt32LE(offset, 42);
        central.push(Buffer.concat([cen, nameBuf]));
        offset += 30 + nameBuf.length + data.length;
      });
      const cenBuf = Buffer.concat(central);
      const eocd = Buffer.alloc(22);
      eocd.writeUInt32LE(0x06054b50, 0);
      eocd.writeUInt16LE(names.length, 8);
      eocd.writeUInt16LE(names.length, 10);
      eocd.writeUInt32LE(cenBuf.length, 12);
      eocd.writeUInt32LE(offset, 16);
      return Buffer.concat(parts.concat([cenBuf, eocd]));
    };

    const tmpDir = os.tmpdir();
    const docxPath = path.join(tmpDir, 'suishoutie-selftest.docx');
    const xlsxPath = path.join(tmpDir, 'suishoutie-selftest.xlsx');
    const docxXml =
      '<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' +
      '<w:p><w:r><w:t>随手贴周报：本周完成知识树与链接抽取</w:t></w:r></w:p>' +
      '<w:p><w:r><w:t>本周新增用户 1200 人，平均摘要长度 260 字。</w:t></w:r></w:p>' +
      '<w:p><w:r><w:t>开源仓库与模型页面见文档超链接。</w:t></w:r></w:p>' +
      '</w:body></w:document>';
    const docxRels =
      '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="https://github.com/demo/suishoutie" TargetMode="External"/>' +
      '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="https://huggingface.co/demo/model" TargetMode="External"/>' +
      '</Relationships>';
    fs.writeFileSync(
      docxPath,
      makeZip({ 'word/document.xml': docxXml, 'word/_rels/document.xml.rels': docxRels })
    );

    const sharedXml =
      '<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="3" uniqueCount="3">' +
      '<si><t>项目</t></si><si><t>星标数</t></si><si><t>随手贴</t></si></sst>';
    const sheetXml =
      '<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>' +
      '<row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row>' +
      '<row r="2"><c r="A2" t="s"><v>2</v></c><c r="B2"><v>128</v></c></row>' +
      '</sheetData></worksheet>';
    const sheetRels =
      '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="https://modelscope.cn/models/demo/suishoutie" TargetMode="External"/>' +
      '</Relationships>';
    fs.writeFileSync(
      xlsxPath,
      makeZip({
        'xl/sharedStrings.xml': sharedXml,
        'xl/worksheets/sheet1.xml': sheetXml,
        'xl/worksheets/_rels/sheet1.xml.rels': sheetRels
      })
    );

    // 真实 Office 文件用的是 deflate 压缩，单独造一份压缩样件验证读取端的 inflate 路径
    const docxDeflatedPath = path.join(tmpDir, 'suishoutie-selftest-deflate.docx');
    fs.writeFileSync(
      docxDeflatedPath,
      makeZip({ 'word/document.xml': docxXml, 'word/_rels/document.xml.rels': docxRels }, true)
    );
    const docxDef = office.readOfficeFile(docxDeflatedPath);
    check('文档解析：压缩（deflate）docx 可读', docxDef.text.includes('1200') && docxDef.hyperlinks.length >= 2, 'len=' + docxDef.text.length);

    const docx = office.readOfficeFile(docxPath);
    check('文档解析：docx 正文非空', docx.text.length > 30, 'len=' + docx.text.length);
    check('文档解析：docx 保留具体数字', docx.text.includes('1200'));
    check('文档解析：docx 读到超链接', (docx.hyperlinks || []).length >= 2, 'links=' + JSON.stringify(docx.hyperlinks));
    const xlsx = office.readOfficeFile(xlsxPath);
    check('文档解析：xlsx 按行读出表格', xlsx.text.includes('项目') && xlsx.text.includes('星标数'), 'text=' + xlsx.text.slice(0, 40));
    check('文档解析：xlsx 读到数值单元格', xlsx.text.includes('128'));
    check('文档解析：xlsx 读到超链接', (xlsx.hyperlinks || []).some((u) => u.includes('modelscope.cn')));

    const cand = (docx.hyperlinks || []).map((u) => {
      const m = fetcher.classifyLink(u) || {};
      return { url: u, kind: m.kind || 'other', site: m.site || '', host: m.host || '' };
    }).concat(fetcher.extractLinksFromText(docx.text));
    const picked = summarizer.pickDocumentLinks(cand, 5);
    check('文档解析：链接按平台优先级挑选', picked.length >= 1 && picked[0].url.includes('github.com'), JSON.stringify(picked.map((p) => p.url)));
    const docAnalysis = await summarizer.analyzeDocument({ fileName: 'suishoutie-selftest.docx', text: docx.text, candidates: picked }, store.getSettings().llm || {});
    check('文档解析：本地模式下生成摘要', docAnalysis.summary.length > 40, 'len=' + docAnalysis.summary.length);
    check('文档解析：本地模式下带回链接', Array.isArray(docAnalysis.links) && docAnalysis.links.length >= 1);
    let docxErr = '';
    try {
      office.readOfficeFile(path.join(tmpDir, 'not-office.doc'));
    } catch (e) {
      docxErr = e.message;
    }
    check('文档解析：旧版 .doc 给出明确提示', docxErr.indexOf('.docx') >= 0 || docxErr.indexOf('另存') >= 0, docxErr);

    // 批量生成 24 条：验证长列表能滚动到最早创建的条目
    let longSummaryItemId = null;
    for (let i = 0; i < 24; i++) {
      // 第一条给一段超长摘要：验证详情摘要区能滚动查看（用户反馈「右侧摘要看不完整」）
      const summary =
        i === 0
          ? '这是一段用于验证详情页滚动能力的长摘要文本。'.repeat(60)
          : '批量生成的测试条目，用于验证列表滚动与知识树归类是否正常。';
      const it = store.addItem({
        title: '滚动测试条目 ' + (i + 1),
        sourceUrl: '',
        sourceType: 'text',
        summary: summary,
        keyPoints: ['批量测试要点'],
        categoryId: i % 2 === 0 ? (cats[0] ? cats[0].id : 0) : 0,
        tags: ['批量'],
        contentHash: hashText('bulk-' + i),
        charCount: 60
      });
      if (i === 0 && it && it.id) longSummaryItemId = it.id;
    }
    check('批量写入：共 26 条', store.getItems().length === 26, 'n=' + store.getItems().length);

    /* ------------------ 3. 界面（offscreen 真实渲染） ------------------ */
    const consoleErrors = [];
    const win = new BrowserWindow({
      width: 1280,
      height: 820,
      show: false,
      webPreferences: {
        preload: path.join(rootDir, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
        offscreen: true
      }
    });
    win.webContents.on('console-message', (...args) => {
      // Electron 新版是 (event, details)，旧版是 (event, level, message)
      const detailArg = args[1];
      const msg = typeof detailArg === 'object' && detailArg ? detailArg.message : args[2] || '';
      const levelArg = typeof detailArg === 'object' && detailArg ? detailArg.level : detailArg;
      if (String(levelArg).toLowerCase().includes('error') || levelArg === 3) consoleErrors.push(msg);
    });

    await win.loadFile(path.join(rootDir, 'renderer', 'index.html'));
    await sleep(1200);

    const js = (code) => win.webContents.executeJavaScript(code, true);

    const hasApp = await js('!!document.getElementById("card-list")');
    check('界面：主界面加载', hasApp === true);

    const cardCount = await js('document.querySelectorAll(".card").length');
    check('界面：卡片列表渲染 26 张', cardCount === 26, 'cards=' + cardCount);

    // 用户反馈「创建完成后之前创建的无法查看」→ 验证列表确实可滚动到最后一条
    const scrollInfo = await js(
      '(function(){var l=document.getElementById("card-list");return {sh:l.scrollHeight,ch:l.clientHeight,ov:getComputedStyle(l).overflowY};})()'
    );
    check('界面：列表内容超出可视区', scrollInfo.sh > scrollInfo.ch + 100, JSON.stringify(scrollInfo));
    await js('var l=document.getElementById("card-list"); l.scrollTop = l.scrollHeight; true');
    await sleep(300);
    const lastVisible = await js(
      '(function(){var cards=document.querySelectorAll("#card-list .card");var last=cards[cards.length-1];' +
        'var r=last.getBoundingClientRect();var box=document.getElementById("card-list").getBoundingClientRect();' +
        'return r.top < box.bottom + 2 && r.bottom > box.top;})()'
    );
    check('界面：滚动到底部可看到最早的知识', lastVisible === true);
    await js('var l=document.getElementById("card-list"); l.scrollTop = 0; true');
    await sleep(200);

    await js('document.querySelector(".card").click(); true');
    await sleep(400);
    const detailTitle = await js('(document.querySelector(".detail-title")||{}).textContent || ""');
    const detailOpen = await js('!document.getElementById("detail").classList.contains("hidden")');
    check('界面：点击卡片打开详情', detailOpen === true && detailTitle.includes('测试条目'), 'title=' + detailTitle);

    const tabs = await js('document.querySelectorAll("#detail-tabs button").length');
    check('界面：详情三标签页', tabs === 3, 'tabs=' + tabs);

    // 用户反馈「右侧摘要看不完整、不能滚动」→ 打开带超长摘要的条目，验证详情栏受窗口高度约束且能滚到底
    await js('document.getElementById("btn-detail-close").click(); true');
    await sleep(250);
    await js('document.querySelector(".card[data-id=\\"' + longSummaryItemId + '\\"]").click(); true');
    await sleep(400);
    const detailScrollInfo = await js(
      '(function(){var b=document.getElementById("detail-body"); b.scrollTop=b.scrollHeight;' +
        'var d=document.getElementById("detail").getBoundingClientRect();' +
        'return {sh:b.scrollHeight,ch:b.clientHeight,st:b.scrollTop,ov:getComputedStyle(b).overflowY,' +
        'dh:d.height,top:d.top,bottom:d.bottom,vh:window.innerHeight};})()'
    );
    check(
      '界面：详情摘要超出时可滚动',
      detailScrollInfo && detailScrollInfo.sh > detailScrollInfo.ch + 20 && detailScrollInfo.st > 0 && detailScrollInfo.ov === 'auto',
      JSON.stringify(detailScrollInfo)
    );
    check(
      '界面：详情栏不超出窗口高度',
      detailScrollInfo && detailScrollInfo.dh <= detailScrollInfo.vh + 1 && detailScrollInfo.bottom <= detailScrollInfo.vh + 1,
      JSON.stringify(detailScrollInfo)
    );
    await js('var b=document.getElementById("detail-body"); b.scrollTop=0; true');

    // 详情长摘要截图（证明右侧摘要区已可滚动、内容不被裁掉）
    try {
      await sleep(150);
      const imgD = await win.webContents.capturePage();
      const shotD = outPath.replace(/\.txt$/, '') + '-detail.png';
      fs.writeFileSync(shotD, imgD.toPNG());
      lines.push(`截图：${shotD}`);
    } catch (e) {
      /* ignore */
    }

    // 笔记页可写
    await js('document.querySelector("#detail-tabs button[data-tab=\\"note\\"]").click(); true');
    await sleep(300);
    const hasNoteArea = await js('!!document.getElementById("note-area")');
    check('界面：笔记编辑器存在', hasNoteArea === true);

    // 关闭详情 → 搜索过滤
    await js('document.getElementById("btn-detail-close").click(); true');
    await sleep(300);
    await js(
      'document.getElementById("search").value="纯文本"; document.getElementById("search").dispatchEvent(new Event("input")); true'
    );
    await sleep(300);
    const filtered = await js('document.querySelectorAll(".card").length');
    check('界面：搜索过滤生效', filtered === 1, 'cards=' + filtered);

    await js(
      'document.getElementById("search").value=""; document.getElementById("search").dispatchEvent(new Event("input")); true'
    );
    await sleep(200);

    // 新增弹窗
    await js('document.getElementById("btn-add").click(); true');
    await sleep(300);
    const addVisible = await js('!document.getElementById("add-modal").classList.contains("hidden")');
    const hasUrlInput = await js('!!document.getElementById("input-url")');
    check('界面：新增弹窗打开', addVisible === true);
    check('界面：新增弹窗含链接输入框', hasUrlInput === true);

    // 关闭新增弹窗
    await js('document.querySelector("#add-modal .modal-head [data-close]").click(); true');
    await sleep(200);

    // 详情页外链芯片（老条目 itemA）
    await js('document.querySelector("#card-list .card[data-id=\\"' + itemA.id + '\\"]").click(); true');
    await sleep(400);
    const linkChips = await js('document.querySelectorAll("#detail-links .link-chip").length');
    check('界面：详情展示可点击外链', linkChips >= 2, 'chips=' + linkChips);
    const linkHosts = await js(
      'Array.prototype.map.call(document.querySelectorAll("#detail-links .link-chip"), function(b){return b.dataset.url;}).join("|")'
    );
    check('界面：外链指向 GitHub / HuggingFace', linkHosts.indexOf('github.com') >= 0 && linkHosts.indexOf('huggingface.co') >= 0, 'hosts=' + linkHosts);
    await js('document.getElementById("btn-detail-close").click(); true');
    await sleep(200);

    // 知识树视图（先把窗口压矮，模拟真实用户的小窗口，逼出滚动需求）
    win.setSize(1280, 520);
    await sleep(300);
    await js('document.querySelector("#view-switch button[data-view=\\"tree\\"]").click(); true');
    await sleep(1800);
    const treeScroll = await js(
      '(function(){var t=document.getElementById("tree-view");t.scrollTop=t.scrollHeight;' +
        'var m=document.querySelector(".main");return {sh:t.scrollHeight,ch:t.clientHeight,st:t.scrollTop,' +
        'ov:getComputedStyle(t).overflowY,mh:m.clientHeight,winH:window.innerHeight};})()'
    );
    check(
      '界面：知识树可上下滚动',
      treeScroll && treeScroll.sh > treeScroll.ch + 20 && treeScroll.st > 0 && /auto|scroll/.test(treeScroll.ov),
      JSON.stringify(treeScroll)
    );
    check(
      '界面：知识树容器不撑出窗口',
      treeScroll && treeScroll.ch <= treeScroll.winH && treeScroll.mh <= treeScroll.winH,
      JSON.stringify(treeScroll)
    );
    await js('var t=document.getElementById("tree-view"); t.scrollTop=0; true');
    await sleep(200);
    const treeCards = await js('document.querySelectorAll(".tree-card").length');
    check('界面：知识树渲染分类卡片', treeCards >= 2, 'cards=' + treeCards);
    const treeSum = await js('(document.querySelector(".tree-summary")||{}).textContent || ""');
    check('界面：分类归类总结已生成', treeSum.length > 20 && treeSum.indexOf('正在整理') < 0, 'sum=' + treeSum.slice(0, 40));
    const treeItems = await js('document.querySelectorAll(".tree-items li").length');
    check('界面：知识树列出分类下的条目', treeItems > 0, 'items=' + treeItems);

    // 知识树截图（作为交付证据）
    try {
      const img2 = await win.webContents.capturePage();
      const shot2 = outPath.replace(/\.txt$/, '') + '-tree.png';
      fs.writeFileSync(shot2, img2.toPNG());
      lines.push(`截图：${shot2}`);
    } catch (e) {
      /* ignore */
    }

    await js('document.querySelector(".tree-items li").click(); true');
    await sleep(400);
    check('界面：知识树条目可下钻详情', (await js('!!document.querySelector(".detail-title")')) === true);
    await js('document.getElementById("btn-detail-close").click(); true');
    await sleep(200);
    await js('document.querySelector("#view-switch button[data-view=\\"list\\"]").click(); true');
    await sleep(300);

    /* ---- 新增：思维导图 / 删除 / 重新抽取 / 去重 ---- */
    await js('document.querySelector("#view-switch button[data-view=\\"map\\"]").click(); true');
    await sleep(700);
    const mapScroll = await js(
      '(function(){var s=document.querySelector(".map-scroll");s.scrollTop=s.scrollHeight;' +
        'var v=document.querySelector(".map-view");return {sh:s.scrollHeight,ch:s.clientHeight,st:s.scrollTop,' +
        'ov:getComputedStyle(s).overflowY,vh:v.clientHeight,winH:window.innerHeight};})()'
    );
    check(
      '界面：思维导图可上下滚动',
      mapScroll && mapScroll.sh > mapScroll.ch + 20 && mapScroll.st > 0 && /auto|scroll/.test(mapScroll.ov),
      JSON.stringify(mapScroll)
    );
    check(
      '界面：思维导图容器不超出窗口',
      mapScroll && mapScroll.ch <= mapScroll.winH && mapScroll.vh <= mapScroll.winH + 1,
      JSON.stringify(mapScroll)
    );
    await js('var s=document.querySelector(".map-scroll"); s.scrollTop=0; true');
    await sleep(200);
    const mapNodes = await js('document.querySelectorAll(".map-node").length');
    const mapItems = await js('document.querySelectorAll(".map-node.item").length');
    const mapHasRoot = await js('!!document.querySelector(".map-node.root")');
    check('界面：思维导图渲染节点（根/分类/条目）', mapNodes >= 4 && mapItems >= 2 && mapHasRoot === true, 'nodes=' + mapNodes + ' items=' + mapItems);
    const mapLinks = await js('document.querySelectorAll(".map-link").length');
    check('界面：思维导图绘制分支连线', mapLinks >= 3, 'lines=' + mapLinks);
    try {
      await sleep(150);
      const img3 = await win.webContents.capturePage();
      const shot3 = outPath.replace(/\.txt$/, '') + '-map.png';
      fs.writeFileSync(shot3, img3.toPNG());
      lines.push(`截图：${shot3}`);
    } catch (e) {
      /* ignore */
    }
    await js('document.querySelector(".map-node.item").dispatchEvent(new MouseEvent("click",{bubbles:true})); true');
    await sleep(400);
    check('界面：思维导图条目可下钻详情', (await js('!!document.querySelector(".detail-title")')) === true);
    await js('document.getElementById("btn-detail-close").click(); true');
    await sleep(200);
    await js('document.querySelector("#view-switch button[data-view=\\"list\\"]").click(); true');
    await sleep(300);

    // 删除：卡片上的 ✕ → 确认 → 条数减一
    const countBeforeDelete = await js('window.api.snapshot().then(function(s){return s.items.length})');
    await js(
      '(function(){var c=document.querySelector("#card-list .card");var d=c.querySelector(".card-del");' +
        'd.dispatchEvent(new MouseEvent("click",{bubbles:true}));return true})()'
    );
    await sleep(300);
    const confirmShown = await js('!document.getElementById("confirm-modal").classList.contains("hidden")');
    check('界面：卡片删除前有确认弹窗', confirmShown === true);
    await js('document.getElementById("confirm-ok").click(); true');
    await sleep(500);
    const countAfterDelete = await js('window.api.snapshot().then(function(s){return s.items.length})');
    check('界面：删除知识生效', countAfterDelete === countBeforeDelete - 1, countBeforeDelete + '->' + countAfterDelete);

    // 重新抽取：无来源链接的手动文本条目应给出明确提示
    const textItemId = (store.getItems().find((i) => !i.sourceUrl) || {}).id;
    const reextractMsg = await js(
      'window.api.reextract(' + Number(textItemId) + ').then(function(r){return r.ok ? "ok" : r.error})'
    );
    check('重新抽取：无来源链接时给出提示', String(reextractMsg).indexOf('来源链接') >= 0, 'msg=' + reextractMsg);

    // 重复检测：同来源再存一次 → 命中已有条目
    const dupPayload = {
      title: '重复测试条目',
      sourceUrl: itemA.sourceUrl,
      sourceType: itemA.sourceType || 'github',
      summary: '重复的内容',
      keyPoints: [],
      tags: [],
      categoryId: itemA.categoryId,
      contentHash: 'dup-test-hash',
      charCount: 10,
      links: []
    };
    const dupMatches = await js(
      'window.api.findDuplicate(' + JSON.stringify({ sourceUrl: itemA.sourceUrl }) + ').then(function(r){return r.matches.length})'
    );
    check('重复检测：同来源命中已有条目', dupMatches >= 1, 'matches=' + dupMatches);
    const simTitle = store.getItems()[0].title;
    const simReason = await js(
      'window.api.findDuplicate(' + JSON.stringify({ title: simTitle }) + ').then(function(r){return (r.matches[0]||{}).reason || ""})'
    );
    check('重复检测：同主题标题也会被识别', simReason === 'similar-title', 'reason=' + simReason + ' title=' + simTitle);
    const dupSaved = await js('window.api.saveCapture(' + JSON.stringify(dupPayload) + ').then(function(r){return r.ok})');
    check('重复检测：允许强制保存重复条目', dupSaved === true);
    await win.loadFile(path.join(rootDir, 'renderer', 'index.html'));
    await sleep(1100);
    const dupPills = await js('document.querySelectorAll(".pill.dup").length');
    check('界面：重复条目在列表中被标注', dupPills >= 2, 'pills=' + dupPills);
    const dedupeVisible = await js('!document.getElementById("btn-dedupe").classList.contains("hidden")');
    check('界面：一键清理重复按钮可见', dedupeVisible === true);
    const countBeforeDedupe = await js('window.api.snapshot().then(function(s){return s.items.length})');
    await js('document.getElementById("btn-dedupe").dispatchEvent(new MouseEvent("click",{bubbles:true})); true');
    await sleep(300);
    await js('document.getElementById("confirm-ok").click(); true');
    await sleep(500);
    const countAfterDedupe = await js('window.api.snapshot().then(function(s){return s.items.length})');
    check('界面：一键清理重复只保留一条', countAfterDedupe === countBeforeDedupe - 1, countBeforeDedupe + '->' + countAfterDedupe);

    await win.loadFile(path.join(rootDir, 'renderer', 'index.html'));
    await sleep(1100);
    win.setSize(1280, 820);
    await sleep(300);

    /* ---- 文档导入：界面入口 + 走真实 IPC 入库 ---- */
    await js('document.getElementById("btn-add").click(); true');
    await sleep(300);
    const hasFileMode = await js('!!document.querySelector("#add-mode button[data-mode=\\"file\\"]")');
    check('界面：新增弹窗有「导入文档」入口', hasFileMode === true);
    await js('document.querySelector("#add-mode button[data-mode=\\"file\\"]").click(); true');
    await sleep(250);
    const filePaneOk = await js(
      '!document.getElementById("pane-file").classList.contains("hidden") && !!document.getElementById("btn-pick-file")'
    );
    check('界面：切到文档模式显示选择文件按钮', filePaneOk === true);
    await js('document.querySelector("#add-modal .modal-head [data-close]").click(); true');
    await sleep(200);

    const importDraft = {
      title: '随手贴周报（自检导入）',
      sourceUrl: docxPath,
      sourceType: 'file',
      summary: docAnalysis.summary,
      keyPoints: docAnalysis.keyPoints || [],
      tags: (docAnalysis.tags || []).concat(['自检']),
      categoryId: cats[0] ? cats[0].id : 0,
      contentHash: 'docx-selftest-hash',
      charCount: docx.text.length,
      links: (docAnalysis.links || []).map((l) => ({
        url: l.url,
        label: l.label || l.url,
        kind: l.kind || 'other',
        site: l.site || ''
      }))
    };
    const beforeImport = await js('window.api.snapshot().then(function(s){return s.items.length})');
    const importRes = await js(
      'window.api.importFile(' +
        JSON.stringify({ draft: importDraft, fetchLinks: false }) +
        ').then(function(r){return JSON.stringify({ok:r.ok,error:r.error||"",src:(r.item&&r.item.sourceType)||"",links:(r.item&&(r.item.links||[]).length)||0})})'
    );
    const imp = JSON.parse(importRes);
    check('文档导入：IPC 入库成功', imp.ok === true && imp.src === 'file', importRes);
    const afterImport = await js('window.api.snapshot().then(function(s){return s.items.length})');
    check('文档导入：知识库条目数 +1', afterImport === beforeImport + 1, beforeImport + '->' + afterImport);
    check('文档导入：文档条目保留候选链接', imp.links >= 1, 'links=' + imp.links);

    const fileItemId = await js(
      'window.api.snapshot().then(function(s){var it=s.items.filter(function(i){return i.sourceType==="file"});return it.length?it[it.length-1].id:0})'
    );
    const trackGuard = await js(
      'window.api.updateItem(' +
        Number(fileItemId) +
        ',{enableTrack:true}).then(function(r){return r.ok?"ok":(r.error||"")})'
    );
    check('文档导入：文档条目禁止开启追踪', String(trackGuard).indexOf('追踪') >= 0, 'msg=' + trackGuard);

    // 截图（证明渲染管线真实可用）
    let shotPath = '';
    try {
      const img = await win.webContents.capturePage();
      shotPath = outPath.replace(/\.txt$/, '') + '-shot.png';
      fs.writeFileSync(shotPath, img.toPNG());
      const size = fs.statSync(shotPath).size;
      check('界面：截图可用', size > 10000, 'bytes=' + size);
      lines.push(`截图：${shotPath}`);
    } catch (e) {
      check('界面：截图可用', false, e.message);
    }

    check('界面：无 console error', consoleErrors.length === 0, consoleErrors.slice(0, 3).join(' | '));

    win.destroy();
  } catch (e) {
    failed++;
    lines.push('[FAIL] 自检异常：' + (e && e.stack ? e.stack.split('\n')[0] : e));
  }

  clearTimeout(guard);
  finish();
}

module.exports = { runSelfTest };
