'use strict';
/* 真实网络抓取验证：node scripts/probe.js <url> */
const { fetchSource } = require('../core/fetcher');
const { summarize } = require('../core/summarize');

(async () => {
  const url = process.argv[2];
  if (!url) {
    console.log('usage: node scripts/probe.js <url>');
    process.exit(1);
  }
  const t0 = Date.now();
  try {
    const r = await fetchSource({ url });
    console.log('TYPE   :', r.sourceType);
    console.log('TITLE  :', r.title);
    console.log('CHARS  :', r.text.length);
    console.log('HEAD   :', r.text.slice(0, 120).replace(/\n/g, ' '));
    const s = await summarize(
      { title: r.title, text: r.text, sourceType: r.sourceType },
      { enabled: false }
    );
    console.log('SUMMARY:', s.summary.slice(0, 200));
    console.log('POINTS :', JSON.stringify(s.keyPoints.slice(0, 3)));
    console.log('TAGS   :', JSON.stringify(s.tags));
    console.log('CATEG  :', s.category);
    console.log('LINKS  :', ((r.links || []).map((l) => l.kind + '|' + l.site + '|' + l.label).join('  ') || '(none)'));
    console.log('COST   :', Date.now() - t0, 'ms');
  } catch (e) {
    console.log('ERROR  :', e.message);
    process.exit(2);
  }
})();
